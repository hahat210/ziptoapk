HASTANE OTOMASYON - FOTOĞRAF YÜKLEMELİ SÜRÜM

Kamera tamamen kaldırılmıştır. Hasta fotoğrafı yalnızca cihazdan dosya seçilerek yüklenir.
Diğer HTML/CSS/JS arayüz ve mevcut sistem korunmuştur.

WINDOWS SETUP OLUŞTURMA:
1) Bilgisayarda Node.js kurulu olsun.
2) Bu klasörde terminal açın.
3) npm install
4) npm run dist
5) dist klasöründeki Hastane-Otomasyon-Setup.exe dosyasını kullanın.

Not: Hasta verileri uygulamanın yerel depolamasında tutulur. Uygulama klasörünü veya kullanıcı verilerini silerseniz kayıtlar da silinebilir.
