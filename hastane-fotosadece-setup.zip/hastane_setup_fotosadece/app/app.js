/* ===================== YARDIMCI FONKSİYONLAR ===================== */
const FOTO_DB='HastaneFotoDB', FOTO_STORE='fotolar';
let fotoCache={};
function fotoDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(FOTO_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(FOTO_STORE))r.result.createObjectStore(FOTO_STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function fotoKaydet(tc,data){if(!data)return;fotoCache[tc]=data;try{const db=await fotoDB();await new Promise((res,rej)=>{const tx=db.transaction(FOTO_STORE,'readwrite');tx.objectStore(FOTO_STORE).put(data,String(tc));tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close()}catch(e){}}
async function fotoGetir(tc){if(fotoCache[tc])return fotoCache[tc];try{const db=await fotoDB();const v=await new Promise((res,rej)=>{const tx=db.transaction(FOTO_STORE,'readonly');const q=tx.objectStore(FOTO_STORE).get(String(tc));q.onsuccess=()=>res(q.result||'');q.onerror=()=>rej(q.error)});db.close();if(v)fotoCache[tc]=v;return v}catch(e){return ''}}
function loadHastalar(){try{return JSON.parse(localStorage.getItem('hastane_hastalar')||'{}')}catch(e){return {}}}
function saveHastalar(d){try{const meta=JSON.parse(JSON.stringify(d));Object.keys(meta).forEach(tc=>delete meta[tc].foto);localStorage.setItem('hastane_hastalar',JSON.stringify(meta));return true}catch(e){toast('Hasta kayıt alanı dolu. Fotoğraflar cihazın geniş depolamasında tutuluyor.','error');return false}}
function fotoDataSikistir(dataUrl,maxW=420,maxH=560,quality=0.62){return new Promise(resolve=>{if(!dataUrl||!dataUrl.startsWith('data:image/'))return resolve(dataUrl);const img=new Image();img.onload=()=>{let w=img.naturalWidth||img.width||maxW,h=img.naturalHeight||img.height||maxH;const oran=Math.min(1,maxW/w,maxH/h);w=Math.max(1,Math.round(w*oran));h=Math.max(1,Math.round(h*oran));const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d',{alpha:false}).drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',quality))};img.onerror=()=>resolve(dataUrl);img.src=dataUrl})}
async function hastalariFotolariOptimizeEt(){const hastalar=loadHastalar();for(const tc of Object.keys(hastalar)){if(hastalar[tc]?.foto?.startsWith('data:image/')){await fotoKaydet(tc,await fotoDataSikistir(hastalar[tc].foto));delete hastalar[tc].foto}}saveHastalar(hastalar)}
function loadStok(){ return JSON.parse(localStorage.getItem('hastane_stok') || '{}'); }
function saveStok(d){ localStorage.setItem('hastane_stok', JSON.stringify(d)); }

function simdi(){
  return new Date().toLocaleString('tr-TR', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
}
function paraFormat(n){ return (Number(n)||0).toFixed(2).replace('.', ',') + ' ₺'; }

function toast(msg, tip){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast' + (tip ? ' ' + tip : '');
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=> el.classList.add('hidden'), 2600);
}

function beep(freq=1250, duration=110){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = freq;
    osc.type = 'square';
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration/1000);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration/1000 + 0.02);
  }catch(e){ /* ses desteklenmiyor olabilir, sorun değil */ }
}

/* ===================== SEKME (TAB) YÖNETİMİ ===================== */
const pageTitles = { kayit:'Hasta Kayıt', muayene:'Muayene', stok:'Stok Yönetimi', kasiyer:'Eczane Kasiyer', borclar:'Borçlar' };

function sekmeyeGec(tab){
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  document.getElementById('pageTitle').textContent = pageTitles[tab];
  if(tab === 'muayene') muayeneStokSelectDoldur();
  if(tab === 'stok') stokTablosunuRenderla();
  if(tab === 'borclar') borclarSekmesiniRenderla();
}

document.querySelectorAll('.nav-btn').forEach(btn=>{
  btn.addEventListener('click', ()=> sekmeyeGec(btn.dataset.tab));
});

/* Saat */
function saatiGuncelle(){
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('tr-TR');
}
setInterval(saatiGuncelle, 1000); saatiGuncelle();

/* ===================== FOTOĞRAF YÜKLEME (kamera yok) ===================== */
let kayitFotoData = '';

document.getElementById('btnKameraCek').addEventListener('click', ()=>{
  fotoCekModuAc(dataUrl=>{
    kayitFotoData = dataUrl;
    document.getElementById('kayitFotoPreview').innerHTML = `<img src="${dataUrl}">`;
    idKartOnizlemeGuncelle();
  });
});
document.getElementById('btnDosyaSec').addEventListener('click', ()=>{
  document.getElementById('kayitFotoInput').click();
});
document.getElementById('kayitFotoInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async ()=>{
    kayitFotoData = await fotoDataSikistir(reader.result);
    document.getElementById('kayitFotoPreview').innerHTML = `<img src="${kayitFotoData}">`;
    idKartOnizlemeGuncelle();
  };
  reader.readAsDataURL(file);
});

document.getElementById('kayitAd').addEventListener('input', idKartOnizlemeGuncelle);
document.getElementById('kayitTc').addEventListener('input', idKartOnizlemeGuncelle);

function idKartOnizlemeGuncelle(){
  const ad = document.getElementById('kayitAd').value.trim() || '— — —';
  const tc = document.getElementById('kayitTc').value.trim() || '—';
  const kart = document.getElementById('idCardPreview');
  kart.querySelector('.id-card-name').textContent = ad;
  document.getElementById('idCardTc').textContent = tc;
  document.getElementById('idCardTarih').textContent = '—';
  const fotoBox = kart.querySelector('.id-card-photo');
  fotoBox.innerHTML = kayitFotoData ? `<img src="${kayitFotoData}">` : '<span>FOTO</span>';
}

function kayitFormunuTemizle(){
  document.getElementById('kayitAd').value = '';
  document.getElementById('kayitTc').value = '';
  kayitFotoData = '';
  document.getElementById('kayitFotoPreview').innerHTML = '<span>Fotoğraf Yok</span>';
  idKartOnizlemeGuncelle();
}

function kayitliHastalariRenderla(){
  const hastalar = loadHastalar();
  const tcler = Object.keys(hastalar);
  document.getElementById('hastaSayisi').textContent = tcler.length;
  const ul = document.getElementById('kayitliHastalarList');
  ul.innerHTML = '';
  if(tcler.length === 0){ ul.innerHTML = '<li class="empty">Henüz hasta kaydı yok</li>'; return; }
  [...tcler].reverse().forEach(tc=>{
    const h = hastalar[tc];
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `<span>👤 ${h.ad}</span><span style="color:var(--text-soft);font-size:11.5px;">${h.tc}</span>`;
    ul.appendChild(li);
  });
}

document.getElementById('btnHastaKaydet').addEventListener('click', async ()=>{
  const ad = document.getElementById('kayitAd').value.trim();
  const tc = document.getElementById('kayitTc').value.trim();
  if(!ad || tc.length !== 11 || !/^\d+$/.test(tc)){
    toast('Ad Soyad girin ve 11 haneli geçerli bir T.C. No yazın.', 'error'); return;
  }
  if(!kayitFotoData){
    toast('Lütfen bir fotoğraf yükleyin.', 'error'); return;
  }
  const hastalar = loadHastalar();
  if(hastalar[tc]){
    toast('Bu T.C. No ile kayıtlı bir hasta zaten var.', 'error'); return;
  }
  const foto = kayitFotoData ? await fotoDataSikistir(kayitFotoData) : '';
  hastalar[tc] = { ad, tc, kayitTarihi: simdi(), muayeneler: [] };
  if(foto) await fotoKaydet(tc,foto);
  if(!saveHastalar(hastalar)) return;
  toast(`${ad} başarıyla kaydedildi. (Toplam ${Object.keys(hastalar).length} hasta)`, 'success');
  kayitFormunuTemizle();
  kayitliHastalariRenderla();
  hastaListeleriniDoldur();
});

function hastaListeleriniDoldur(){
  const hastalar=loadHastalar();
  const list=[...Object.values(hastalar)].sort((a,b)=>(a.ad||'').localeCompare(b.ad||'','tr'));
  ['muayeneHastaSec','kasiyerHastaSec'].forEach(id=>{
    const sel=document.getElementById(id); if(!sel) return;
    const mevcut=sel.value;
    sel.innerHTML='<option value="">Kayıtlı hasta seç...</option>';
    list.forEach(h=>{ const o=document.createElement('option'); o.value=h.tc; o.textContent=`${h.ad} — ${h.tc}`; sel.appendChild(o); });
    if(hastalar[mevcut]) sel.value=mevcut;
  });
}

/* ===================== MUAYENE ===================== */
let secilenHastaTc = null;
let aktifRecete = [];

function muayeneHastaSec(tc){
  const hastalar=loadHastalar(), hasta=hastalar[tc];
  if(!hasta){toast('Bu T.C. ile kayıtlı hasta bulunamadı.','error');return false;}
  secilenHastaTc=tc; aktifRecete=[];
  document.getElementById('muayeneTcSorgu').value=tc;
  document.getElementById('muayeneHastaSec').value=tc;
  document.getElementById('muayeneHastaAd').textContent=hasta.ad;
  document.getElementById('muayeneHastaTc').textContent=hasta.tc;
  const fotoBox=document.getElementById('muayeneHastaKart').querySelector('.id-card-photo');
  fotoBox.innerHTML='<span>FOTO</span>'; fotoGetir(tc).then(f=>{if(f)fotoBox.innerHTML=`<img src="${f}">`;});
  document.getElementById('muayeneNot').value='';
  gecmisMuayeneleriDoldur(hasta); receteListesiRenderla(); muayeneStokSelectDoldur();
  return true;
}

document.getElementById('btnHastaBul').addEventListener('click',()=>{
  const tc=document.getElementById('muayeneTcSorgu').value.trim();
  if(muayeneHastaSec(tc)) document.getElementById('muayeneHastaSec').value=tc;
});
document.getElementById('muayeneHastaSec').addEventListener('change',e=>{if(e.target.value) muayeneHastaSec(e.target.value);});

function gecmisMuayeneleriDoldur(hasta){
  const ul = document.getElementById('muayeneGecmisList');
  ul.innerHTML = '';
  if(!hasta.muayeneler || hasta.muayeneler.length === 0){
    ul.innerHTML = '<li class="empty">Geçmiş muayene yok</li>'; return;
  }
  const siraliListe = hasta.muayeneler.map((m, i)=>({m, i})).reverse();
  siraliListe.forEach(({m})=>{
    const li = document.createElement('li');
    const receteHtml = (m.receteler && m.receteler.length > 0)
      ? m.receteler.map(ad=>`<div>💊 ${ad}</div>`).join('')
      : '<div>Reçete verilmedi</div>';
    const odemeEtiket = (m.receteler && m.receteler.length > 0)
      ? (m.odendiMi ? '<span class="tag-ok">✔ ÖDENDİ</span>' : '<span class="tag-wait">ÖDENMEDİ</span>')
      : '';
    li.innerHTML = `
      <div class="gecmis-baslik">
        <span>${m.tarih}</span>${odemeEtiket}
      </div>
      <div class="gecmis-detay hidden">
        <div style="white-space:pre-wrap;margin-bottom:6px;">${(m.not||'').replace(/</g,'&lt;')}</div>
        ${receteHtml}
      </div>
    `;
    li.querySelector('.gecmis-baslik').addEventListener('click', ()=>{
      li.querySelector('.gecmis-detay').classList.toggle('hidden');
      document.getElementById('muayeneNot').value = m.not || '';
    });
    ul.appendChild(li);
  });
}

function muayeneStokSelectDoldur(){
  const sel = document.getElementById('muayeneIlacSecim');
  const stok = loadStok();
  sel.innerHTML = '';
  const isimler = Object.keys(stok);
  if(isimler.length === 0){ sel.innerHTML = '<option value="">Stokta ilaç yok</option>'; return; }
  isimler.forEach(ad=>{
    const opt = document.createElement('option');
    opt.value = ad;
    opt.textContent = `${ad} (${stok[ad].adet} adet)`;
    sel.appendChild(opt);
  });
}

document.getElementById('btnIlacRecetele').addEventListener('click', ()=>{
  if(!secilenHastaTc){ toast('Önce bir hasta bulun.', 'error'); return; }
  const ad = document.getElementById('muayeneIlacSecim').value;
  if(!ad){ toast('Stokta ilaç yok.', 'error'); return; }
  const stok = loadStok();
  if(!stok[ad] || stok[ad].adet <= 0){ toast(`${ad} stokta yok.`, 'error'); return; }
  stok[ad].adet -= 1;
  saveStok(stok);
  aktifRecete.push(ad);
  receteListesiRenderla();
  muayeneStokSelectDoldur();
  stokTablosunuRenderla();
  toast(`${ad} reçeteye eklendi, stoktan düşüldü.`);
});

function receteListesiRenderla(){
  const ul = document.getElementById('muayeneReceteList');
  ul.innerHTML = '';
  if(aktifRecete.length === 0){ ul.innerHTML = '<li class="empty">Reçeteye ilaç eklenmedi</li>'; return; }
  aktifRecete.forEach(ad=>{
    const li = document.createElement('li'); li.innerHTML = `<span>💊 ${ad}</span>`;
    ul.appendChild(li);
  });
}

document.getElementById('btnMuayeneKaydet').addEventListener('click', ()=>{
  if(!secilenHastaTc){ toast('Önce bir hasta bulun.', 'error'); return; }
  const not = document.getElementById('muayeneNot').value.trim();
  if(!not){ toast('Muayene notu yazmadınız.', 'error'); return; }
  const hastalar = loadHastalar();
  const hasta = hastalar[secilenHastaTc];
  hasta.muayeneler.push({
    tarih: simdi(),
    not,
    receteler: [...aktifRecete],
    odendiMi: aktifRecete.length === 0
  });
  saveHastalar(hastalar);
  toast('Muayene arşive eklendi.', 'success');
  aktifRecete = [];
  receteListesiRenderla();
  gecmisMuayeneleriDoldur(hasta);
  document.getElementById('muayeneNot').value = '';
});

/* ===================== STOK YÖNETİMİ ===================== */
document.getElementById('btnStokEkle').addEventListener('click', ()=>{
  const adRaw = document.getElementById('stokAd').value.trim();
  const adet = parseInt(document.getElementById('stokAdet').value, 10);
  const fiyat = parseFloat(document.getElementById('stokFiyat').value);
  if(!adRaw || isNaN(adet) || adet < 0){ toast('İlaç adı ve geçerli adet girin.', 'error'); return; }
  const ad = adRaw.charAt(0).toUpperCase() + adRaw.slice(1);
  const stok = loadStok();
  if(stok[ad]){
    stok[ad].adet += adet;
    if(!isNaN(fiyat)) stok[ad].fiyat = fiyat;
  }else{
    stok[ad] = { adet, fiyat: isNaN(fiyat) ? 0 : fiyat };
  }
  saveStok(stok);
  toast(`${ad} stoğa eklendi.`, 'success');
  document.getElementById('stokAd').value = '';
  document.getElementById('stokAdet').value = '';
  document.getElementById('stokFiyat').value = '';
  stokTablosunuRenderla();
  muayeneStokSelectDoldur();
});

function stokTablosunuRenderla(){
  const stok = loadStok();
  const body = document.getElementById('stokTabloBody');
  body.innerHTML = '';
  const isimler = Object.keys(stok);
  if(isimler.length === 0){
    body.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-soft);">Stok boş</td></tr>';
    return;
  }
  isimler.forEach(ad=>{
    const s = stok[ad];
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${ad}</td>
      <td>${s.adet}</td>
      <td>${paraFormat(s.fiyat)}</td>
      <td><span class="pill ${s.adet>0?'pill-ok':'pill-no'}">${s.adet>0?'STOKTA':'YOK'}</span></td>
      <td><button class="btn btn-danger" style="padding:6px 10px;font-size:11px;">Sil</button></td>
    `;
    tr.querySelector('button').addEventListener('click', ()=>{
      if(confirm(`${ad} tamamen silinsin mi?`)){
        const s2 = loadStok(); delete s2[ad]; saveStok(s2);
        stokTablosunuRenderla(); muayeneStokSelectDoldur();
      }
    });
    body.appendChild(tr);
  });
}

/* ===================== ECZANE KASİYER ===================== */
let kasiyerHastaTc = null;
let kasiyerKalemler = []; // {muayeneIndex, ad, fiyat, okutuldu}

document.getElementById('btnKasiyerBul').addEventListener('click', ()=>{
  kasiyerHastaAra(document.getElementById('kasiyerTcSorgu').value.trim());
});
document.getElementById('kasiyerHastaSec').addEventListener('change',e=>{if(e.target.value) kasiyerHastaAra(e.target.value);});

function kasiyerHastaAra(tc){
  const hastalar = loadHastalar();
  const hasta = hastalar[tc];
  if(!hasta){ toast('Bu T.C. ile kayıtlı hasta bulunamadı.', 'error'); return; }
  document.getElementById('kasiyerTcSorgu').value = tc;
  document.getElementById('kasiyerHastaSec').value = tc;
  kasiyerHastaTc = tc;
  document.getElementById('kasiyerHastaAd').textContent = hasta.ad;
  document.getElementById('kasiyerHastaTc').textContent = hasta.tc;
  const fotoBox = document.getElementById('kasiyerHastaKart').querySelector('.id-card-photo');
  fotoBox.innerHTML = '<span>FOTO</span>';
  fotoGetir(tc).then(f=>{ if(f) fotoBox.innerHTML=`<img src="${f}">`; });
  kalemleriTopla(hasta);
  bekleyenListesiRenderla();
  fisRenderla();
}

function kalemleriTopla(hasta){
  const stok = loadStok();
  kasiyerKalemler = [];
  (hasta.muayeneler || []).forEach((m, mi)=>{
    if(m.odendiMi) return;
    (m.receteler || []).forEach((ad)=>{
      kasiyerKalemler.push({
        muayeneIndex: mi, ad,
        fiyat: (stok[ad] && stok[ad].fiyat) || 0,
        okutuldu: false
      });
    });
  });
}

function bekleyenListesiRenderla(){
  const ul = document.getElementById('kasiyerBekleyenList');
  ul.innerHTML = '';
  if(kasiyerKalemler.length === 0){ ul.innerHTML = '<li class="empty">Bekleyen ödenmemiş ilaç yok</li>'; return; }
  kasiyerKalemler.forEach((k, idx)=>{
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `
      <span class="oturum-satiri">💊 ${k.ad} — ${paraFormat(k.fiyat)}</span>
      <button class="okut-btn" data-idx="${idx}" ${k.okutuldu?'disabled':''}>${k.okutuldu?'✔ OKUTULDU':'📟 Okut'}</button>
    `;
    ul.appendChild(li);
  });
  ul.querySelectorAll('.okut-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> sahteOkut(parseInt(btn.dataset.idx, 10), btn));
  });
}

function sahteOkut(idx, btnEl){
  if(kasiyerKalemler[idx].okutuldu) return;
  btnEl.disabled = true;
  btnEl.textContent = 'Taranıyor…';
  setTimeout(()=>{
    kasiyerKalemler[idx].okutuldu = true;
    beep();
    toast(`${kasiyerKalemler[idx].ad} okutuldu ✔`, 'success');
    bekleyenListesiRenderla();
    fisRenderla();
  }, 550);
}

function fisRenderla(){
  const fis = document.getElementById('kasiyerFis');
  if(!kasiyerHastaTc || kasiyerKalemler.length === 0){
    fis.innerHTML = '<div class="fis-empty">' + (kasiyerHastaTc ? 'Bu hastanın ödenmemiş ilacı yok.' : 'Henüz bir hasta seçilmedi.') + '</div>';
    document.getElementById('kasiyerToplam').textContent = paraFormat(0);
    document.getElementById('btnNakitOde').disabled = true;
    document.getElementById('btnKartOku').disabled = true;
    return;
  }
  fis.innerHTML = kasiyerKalemler.map(k=>
    `<div class="fis-row ${k.okutuldu?'checked':''}">
      <span>${k.okutuldu?'✔ ':''}${k.ad}</span><span>${paraFormat(k.fiyat)}</span>
    </div>`
  ).join('');
  const toplam = kasiyerKalemler.reduce((s,k)=> s + k.fiyat, 0);
  document.getElementById('kasiyerToplam').textContent = paraFormat(toplam);
  const hepsiOkutuldu = kasiyerKalemler.every(k=>k.okutuldu);
  document.getElementById('btnNakitOde').disabled = !hepsiOkutuldu;
  document.getElementById('btnKartOku').disabled = !hepsiOkutuldu;
}

function odemeyiTamamla(yontem){
  if(!kasiyerHastaTc) return;
  const hastalar = loadHastalar();
  const hasta = hastalar[kasiyerHastaTc];
  const muayeneIndexleri = new Set(kasiyerKalemler.map(k=>k.muayeneIndex));
  muayeneIndexleri.forEach(mi=>{ hasta.muayeneler[mi].odendiMi = true; });
  saveHastalar(hastalar);
  toast(`Ödeme tamamlandı (${yontem}).`, 'success');
  kasiyerKalemler = [];
  bekleyenListesiRenderla();
  fisRenderla();
}

document.getElementById('btnNakitOde').addEventListener('click', ()=>{
  odemeyiTamamla('NAKİT');
});

document.getElementById('btnKasiyerYeni').addEventListener('click', ()=>{
  kasiyerHastaTc = null;
  kasiyerKalemler = [];
  document.getElementById('kasiyerTcSorgu').value = '';
  document.getElementById('kasiyerHastaSec').value = '';
  document.getElementById('kasiyerHastaAd').textContent = 'Hasta seçilmedi';
  document.getElementById('kasiyerHastaTc').textContent = '—';
  document.getElementById('kasiyerHastaKart').querySelector('.id-card-photo').innerHTML = '<span>FOTO</span>';
  bekleyenListesiRenderla();
  fisRenderla();
});

/* ===================== MİNİ POS (KART OKUMA) ===================== */
const posModal=document.getElementById('posModal'),posStage=document.getElementById('posStage'),posAmount=document.getElementById('posAmount'),posPinDots=document.getElementById('posPinDots'),posMsg=document.getElementById('posMsg'),posKeypad=document.getElementById('posKeypad'),posReceipt=document.getElementById('posReceipt'),posContactless=document.getElementById('posContactless');
let posPin='',posIslemBitti=false,posPinTimer=null,posOdemeBasarili=false,posOdemeYontemi='ŞİFRE';
function posTimerTemizle(){if(posPinTimer){clearTimeout(posPinTimer);posPinTimer=null}}
function posSes(tip){
  try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const c=new C(),g=c.createGain(),o=c.createOscillator();o.connect(g);g.connect(c.destination);let n=c.currentTime;
    if(tip==='key'){o.frequency.value=620;g.gain.value=.035;o.start(n);o.stop(n+.045)}
    else if(tip==='print'){o.type='square';for(let i=0;i<7;i++){o.frequency.setValueAtTime(420+(i%2)*110,n+i*.045);g.gain.setValueAtTime(.001,n+i*.045);g.gain.exponentialRampToValueAtTime(.07,n+i*.045+.008);g.gain.exponentialRampToValueAtTime(.001,n+i*.045+.035)}o.start(n);o.stop(n+.34)}
    else if(tip==='tear'){o.type='sawtooth';o.frequency.setValueAtTime(1700,n);o.frequency.exponentialRampToValueAtTime(120,n+.32);g.gain.setValueAtTime(.001,n);g.gain.exponentialRampToValueAtTime(.18,n+.02);g.gain.exponentialRampToValueAtTime(.001,n+.34);o.start(n);o.stop(n+.35)}
    else if(tip==='ok'){o.frequency.value=880;g.gain.value=.07;o.start(n);o.stop(n+.11);setTimeout(()=>{try{const c2=new C(),o2=c2.createOscillator(),g2=c2.createGain();o2.frequency.value=1320;g2.gain.value=.05;o2.connect(g2);g2.connect(c2.destination);o2.start();o2.stop(c2.currentTime+.14)}catch(e){}},100)}
    else {o.frequency.value=190;g.gain.value=.06;o.start(n);o.stop(n+.25)}
  }catch(e){}
}
function posPinEkraninaGec(){if(posIslemBitti)return;posTimerTemizle();posStage.textContent='ŞİFRE GİRİN';posMsg.textContent='4 haneli kart şifresini girin';posContactless.classList.add('hidden');posKeypad.classList.remove('hidden');posKeypad.querySelectorAll('button').forEach(b=>b.disabled=false);posPin='';posPinDotsGuncelle();posSes('key');}
function posFisiHazirla(toplam,yontem){
  const satirlar=kasiyerKalemler.map(k=>`<div class="fis-row"><span>${k.ad}</span><span>${paraFormat(k.fiyat)}</span></div>`).join('');
  posReceipt.innerHTML=`<div class="pos-paper-title">ECZANE FİŞİ</div><div class="pos-paper-date">${simdi()}</div>${satirlar}<div class="fis-row pos-paper-total"><span>TOPLAM</span><span>${paraFormat(toplam)}</span></div><div class="pos-paper-ok">${yontem==='TEMASSIZ'?'TEMASSIZ + ŞİFRE':'KART + ŞİFRE'} İLE ÖDENDİ ✔</div><div class="pos-paper-hint">👉 Fişi sağa çekip koparın</div>`;
  posReceipt.classList.remove('hidden','pos-paper-tear','pos-paper-drag');posReceipt.style.transform='';
  requestAnimationFrame(()=>posReceipt.classList.add('pos-paper-print'));posSes('print');
}
function posFisiKopar(){
  if(!posOdemeBasarili)return;posReceipt.classList.add('pos-paper-tear');posSes('tear');if(navigator.vibrate)navigator.vibrate([25,20,45]);
  setTimeout(()=>{posReceipt.classList.add('hidden');posReceipt.classList.remove('pos-paper-tear','pos-paper-print');posTimerTemizle();posModal.classList.add('hidden');odemeyiTamamla(posOdemeYontemi);},430);
}
function posSonucGoster(basarili,toplam,yontem){
  posIslemBitti=true;posOdemeBasarili=basarili;posOdemeYontemi=yontem;posTimerTemizle();posKeypad.querySelectorAll('button').forEach(b=>b.disabled=true);posContactless.classList.add('hidden');
  if(!basarili){posStage.textContent='❌ YETERSİZ BAKİYE';posMsg.textContent='Kartta yeterli bakiye bulunamadı.';posSes('fail');posReceipt.classList.add('hidden');posReceipt.innerHTML='';return;}
  posStage.textContent='✅ ONAYLANDI';posMsg.textContent='Fiş yukarıdan çıkıyor…';posSes('ok');posFisiHazirla(toplam,yontem);
}
function posOdemeBaslat(yontem){
  if(posIslemBitti||kasiyerKalemler.length===0)return;const toplam=kasiyerKalemler.reduce((s,k)=>s+k.fiyat,0);posIslemBitti=true;posOdemeYontemi=yontem;posStage.textContent='İŞLEM YAPILIYOR…';posMsg.textContent='Şifre kontrol ediliyor…';posKeypad.querySelectorAll('button').forEach(b=>b.disabled=true);
  setTimeout(()=>{const yetersizBakiye=Math.random()<.10;posIslemBitti=false;posSonucGoster(!yetersizBakiye,toplam,yontem)},850);
}
document.getElementById('btnKartOku').addEventListener('click',()=>{
  if(kasiyerKalemler.length===0)return;posTimerTemizle();posPin='';posIslemBitti=false;posOdemeBasarili=false;posStage.textContent='KARTI YAKLAŞTIRIN';posMsg.textContent='Üst bölgeye dokunun: TEMASSIZ';posAmount.textContent=paraFormat(kasiyerKalemler.reduce((s,k)=>s+k.fiyat,0));posPinDotsGuncelle();posReceipt.classList.add('hidden');posReceipt.innerHTML='';posKeypad.classList.add('hidden');posContactless.classList.remove('hidden');posModal.classList.remove('hidden');posPinTimer=setTimeout(()=>{posOdemeYontemi='ŞİFRE';posPinEkraninaGec()},5000);
});
document.getElementById('btnPosClose').addEventListener('click',()=>{posTimerTemizle();posModal.classList.add('hidden')});
function posPinDotsGuncelle(){posPinDots.querySelectorAll('span').forEach((x,i)=>x.classList.toggle('filled',i<posPin.length))}
posContactless.addEventListener('click',()=>{posTimerTemizle();posOdemeYontemi='TEMASSIZ';posStage.textContent='TEMASSIZ OKUNDU';posMsg.textContent='Şimdi kart şifresini girin';posPinEkraninaGec()});
posKeypad.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||posIslemBitti)return;const k=b.dataset.k;if(k==='C'){posPin=posPin.slice(0,-1);posPinDotsGuncelle();posSes('key');return}if(k==='OK'){if(posPin.length<4){posMsg.textContent='En az 4 haneli şifre girin.';return}posOdemeYontemi=posOdemeYontemi==='TEMASSIZ'?'TEMASSIZ':'ŞİFRE';posOdemeBaslat(posOdemeYontemi);return}if(/^\d$/.test(k)&&posPin.length<4){posPin+=k;posPinDotsGuncelle();posSes('key')}});
let fisDrag=false,fisStartX=0,fisX=0;
posReceipt.addEventListener('pointerdown',e=>{if(!posOdemeBasarili)return;fisDrag=true;fisStartX=e.clientX;fisX=0;posReceipt.setPointerCapture?.(e.pointerId);posReceipt.classList.add('pos-paper-drag')});
posReceipt.addEventListener('pointermove',e=>{if(!fisDrag)return;fisX=Math.max(0,e.clientX-fisStartX);posReceipt.style.transform=`translate(calc(-50% + ${fisX}px), -100%) rotate(${Math.min(9,fisX/25)}deg)`});
posReceipt.addEventListener('pointerup',()=>{if(!fisDrag)return;fisDrag=false;posReceipt.classList.remove('pos-paper-drag');if(fisX>Math.max(70,posReceipt.offsetWidth*.3)){posReceipt.style.transform='translate(125vw,-100%) rotate(15deg)';posFisiKopar()}else{posReceipt.style.transform='translate(-50%,-100%) rotate(0)'}});
posReceipt.addEventListener('pointercancel',()=>{fisDrag=false;posReceipt.style.transform='translate(-50%,-100%) rotate(0)'});

/* ===================== BORÇLAR ===================== */
function tumBorclariHesapla(){
  const hastalar = loadHastalar();
  const stok = loadStok();
  const sonuc = [];
  Object.values(hastalar).forEach(hasta=>{
    let tutar = 0;
    (hasta.muayeneler || []).forEach(m=>{
      if(m.odendiMi) return;
      (m.receteler || []).forEach(ad=>{ tutar += (stok[ad] && stok[ad].fiyat) || 0; });
    });
    if(tutar > 0) sonuc.push({ tc: hasta.tc, ad: hasta.ad, tutar });
  });
  return sonuc;
}

function genelBorcToplami(){
  return tumBorclariHesapla().reduce((s,x)=> s + x.tutar, 0);
}

function borclarSekmesiniRenderla(){
  const borclar = tumBorclariHesapla();
  document.getElementById('borcGenelToplam').textContent = paraFormat(genelBorcToplami());
  const ul = document.getElementById('borclarList');
  ul.innerHTML = '';
  if(borclar.length === 0){ ul.innerHTML = '<li class="empty">Borcu olan hasta yok 🎉</li>'; return; }
  borclar.forEach(b=>{
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `
      <span>👤 ${b.ad} <span style="color:var(--text-soft);font-size:11px;">(${b.tc})</span></span>
      <span class="borc-tutar">${paraFormat(b.tutar)}</span>
      <button class="okut-btn" style="background:var(--teal-700);">Öde</button>
    `;
    li.querySelector('.okut-btn').addEventListener('click', ()=>{
      sekmeyeGec('kasiyer');
      kasiyerHastaAra(b.tc);
    });
    ul.appendChild(li);
  });
}

/* ===================== BORÇ HATIRLATMA (her 5 dakikada bir) ===================== */
if('Notification' in window && Notification.permission === 'default'){
  try{ Notification.requestPermission(); }catch(e){ /* yoksay */ }
}

function borcHatirlatmasiniKontrolEt(){
  const toplam = genelBorcToplami();
  if(toplam <= 0) return;
  const mesaj = `Toplam ${paraFormat(toplam)} tahsil edilmemiş borç var.`;
  if('Notification' in window && Notification.permission === 'granted'){
    try{
      new Notification('🧾 Borç Hatırlatma', { body: mesaj, icon: 'icon-192.png' });
      return;
    }catch(e){ /* toast'a düş */ }
  }
  toast(mesaj, 'error');
}
setInterval(borcHatirlatmasiniKontrolEt, 5 * 60 * 1000);

/* Yatay (landscape) kilidi dene — APK/PWA olarak kurulduğunda çoğu cihazda çalışır */
try{
  if(screen.orientation && screen.orientation.lock){
    screen.orientation.lock('landscape').catch(()=>{});
  }
}catch(e){ /* desteklenmiyorsa CSS uyarısı devrede */ }

/* ===================== BAŞLANGIÇ ===================== */
hastalariFotolariOptimizeEt();
stokTablosunuRenderla();
muayeneStokSelectDoldur();
receteListesiRenderla();
bekleyenListesiRenderla();
fisRenderla();
kayitliHastalariRenderla();
hastaListeleriniDoldur();
idKartOnizlemeGuncelle();
