/* =========================================================================
   POS TERMİNALİ — bağımsız uygulama
   Ana Merkez ile aynı Firebase Realtime Database yolunu kullanır:
     sync/{oturumKodu}/istek   -> Ana Merkez'den POS'a ödeme isteği
     sync/{oturumKodu}/sonuc   -> POS'tan Ana Merkez'e sonuç
   Bu dosya Ana Merkez tarafına hiç dokunmaz, sadece aynı sözleşmeyi konuşur.
   ========================================================================= */

/* ---------------- Firebase varsayılan yapılandırması ----------------
   Aynı oyunun Ana Merkez tarafındaki ile birebir aynı olmalı. */
const POS_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBbGR4xRho-jXPZeNdPINO31h_gLc9epBU",
  authDomain: "hastane-oyunu.firebaseapp.com",
  databaseURL: "https://hastane-oyunu-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "hastane-oyunu",
  storageBucket: "hastane-oyunu.firebasestorage.app",
  messagingSenderId: "1079050009396",
  appId: "1:1079050009396:web:e4f4c0069dab54824b4361"
};
const POS_OTURUM_KODU_VARSAYILAN = "kardesler1";

/* ---------------- Yerel durum ---------------- */
let firebaseDB = null;
let firebaseHazir = false;
let baglantiAktif = false;      // kullanıcı "Bağlan" dedi mi
let dinleyiciRef = null, dinleyiciFn = null;
let sonIslenenIstekId = null;

let pin = '';
let islemBitti = false;
let odemeBasarili = false;
let pinTimer = null;
let mevcutIstek = null;         // { id, tutar, baglam }
let fisSuruklemeAktif = false, fisBaslangicX = 0, fisX = 0;

/* ---------------- DOM ---------------- */
const $ = (id) => document.getElementById(id);
const connDot = $('connDot'), connText = $('connText');
const btnBaglan = $('btnBaglan'), btnBaglantiKes = $('btnBaglantiKes'), btnAyarlar = $('btnAyarlar');
const screenStage = $('screenStage'), screenAmount = $('screenAmount'), screenMsg = $('screenMsg');
const contactlessPad = $('contactlessPad'), pinDots = $('pinDots'), keypad = $('keypad');
const receipt = $('receipt');
const ayarModal = $('ayarModal'), ayarOturumKodu = $('ayarOturumKodu'), ayarConfig = $('ayarConfig');
const screenClock = $('screenClock');

/* ---------------- Saat ---------------- */
function saatiGuncelle(){
  const d = new Date();
  screenClock.textContent = d.toLocaleTimeString('tr-TR', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
}
setInterval(saatiGuncelle, 1000); saatiGuncelle();

/* ---------------- Toast ---------------- */
function toast(msg, tip){
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast' + (tip ? ' ' + tip : '');
  t.classList.remove('hidden');
  clearTimeout(toast._h);
  toast._h = setTimeout(()=> t.classList.add('hidden'), 2600);
}

/* ---------------- Para formatı ---------------- */
function paraFormat(n){
  return (Number(n)||0).toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' ₺';
}

/* ---------------- Gerçekçi ses efektleri (Web Audio, 3D benzeri stereo/reverb hissi) ---------------- */
let sharedAudioCtx = null;
function audioCtx(){
  if(!sharedAudioCtx){
    const C = window.AudioContext || window.webkitAudioContext;
    if(!C) return null;
    sharedAudioCtx = new C();
  }
  if(sharedAudioCtx.state === 'suspended') sharedAudioCtx.resume().catch(()=>{});
  return sharedAudioCtx;
}
// basit convolver ile hafif "oda" hissi -> 3D/gerçekçi algısı
function odaEfektiEkle(ctx, kaynakNode){
  try{
    const conv = ctx.createConvolver();
    const rate = ctx.sampleRate, sure = 0.6;
    const buf = ctx.createBuffer(2, rate*sure, rate);
    for(let ch=0; ch<2; ch++){
      const data = buf.getChannelData(ch);
      for(let i=0;i<data.length;i++){
        data[i] = (Math.random()*2-1) * Math.pow(1-i/data.length, 2.5);
      }
    }
    conv.buffer = buf;
    const dry = ctx.createGain(); dry.gain.value = 0.85;
    const wet = ctx.createGain(); wet.gain.value = 0.10;
    kaynakNode.connect(dry).connect(ctx.destination);
    kaynakNode.connect(conv).connect(wet).connect(ctx.destination);
  }catch(e){
    kaynakNode.connect(ctx.destination);
  }
}
function panliTon(freq, sure, tip, panVal, hacim){
  const ctx = audioCtx(); if(!ctx) return;
  try{
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const pan = (ctx.createStereoPanner) ? ctx.createStereoPanner() : null;
    osc.type = tip || 'sine';
    osc.frequency.value = freq;
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(hacim||0.18, now+0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now+sure);
    osc.connect(gain);
    if(pan){ pan.pan.value = panVal||0; gain.connect(pan); odaEfektiEkle(ctx, pan); }
    else{ odaEfektiEkle(ctx, gain); }
    osc.start(now); osc.stop(now+sure+0.03);
  }catch(e){}
}
const SES = {
  tus(){ panliTon(1200+Math.random()*80, 0.05, 'square', 0, 0.09); },
  baglaniyor(){ panliTon(620, 0.08, 'sine', -0.3, 0.06); },
  bagliOldu(){ panliTon(880,0.1,'sine',0,0.12); setTimeout(()=>panliTon(1320,0.14,'sine',0,0.11),110); },
  baglantiKesildi(){ panliTon(300,0.22,'sawtooth',0,0.10); },
  veriGeldi(){ panliTon(700,0.06,'sine',0.3,0.08); setTimeout(()=>panliTon(700,0.06,'sine',0.3,0.08),160); setTimeout(()=>panliTon(700,0.06,'sine',0.3,0.08),320); },
  islemBasladi(){ panliTon(500,0.3,'sine',0,0.08); },
  onay(){ panliTon(900,0.12,'sine',0,0.14); setTimeout(()=>panliTon(1400,0.18,'sine',0,0.13),120); },
  hata(){ panliTon(220,0.35,'square',0,0.14); },
  yazdirma(){
    for(let i=0;i<6;i++){
      setTimeout(()=>panliTon(430+((i%2)*70), 0.05, 'square', (i%2? .25:-.25), 0.07), i*70);
    }
  },
  yirtma(){
    const ctx = audioCtx(); if(!ctx) return;
    try{
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.type = 'sawtooth';
      const now = ctx.currentTime;
      osc.frequency.setValueAtTime(2000, now);
      osc.frequency.exponentialRampToValueAtTime(150, now+0.3);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.16, now+0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now+0.32);
      osc.connect(gain); odaEfektiEkle(ctx, gain);
      osc.start(now); osc.stop(now+0.34);
    }catch(e){}
  }
};
document.addEventListener('pointerdown', ()=>{ audioCtx(); }, {once:true});

/* ---------------- Bağlantı ayarları ---------------- */
function ayarlariYukle(){
  try{
    const ozel = JSON.parse(localStorage.getItem('pos_baglanti_ayar') || 'null');
    if(ozel && ozel.config && ozel.oturumKodu) return ozel;
  }catch(e){}
  return { config: POS_FIREBASE_CONFIG, oturumKodu: POS_OTURUM_KODU_VARSAYILAN };
}
function yolOlustur(alt){
  const ayar = ayarlariYukle();
  return `sync/${ayar.oturumKodu}/${alt}`;
}

btnAyarlar.addEventListener('click', ()=>{
  const ayar = ayarlariYukle();
  ayarOturumKodu.value = ayar.oturumKodu;
  ayarConfig.value = JSON.stringify(ayar.config, null, 2);
  ayarModal.classList.remove('hidden');
});
$('btnAyarKapat').addEventListener('click', ()=> ayarModal.classList.add('hidden'));
$('btnAyarKaydet').addEventListener('click', ()=>{
  const kodu = ayarOturumKodu.value.trim();
  const raw = ayarConfig.value.trim();
  if(!kodu || !raw){ toast('Oturum kodu ve yapılandırmayı girin.', 'error'); return; }
  try{
    const config = JSON.parse(raw);
    localStorage.setItem('pos_baglanti_ayar', JSON.stringify({oturumKodu:kodu, config}));
    toast('Ayarlar kaydedildi.', 'success');
    ayarModal.classList.add('hidden');
    if(baglantiAktif){ baglantiyiKes(); baglan(); }
  }catch(e){
    toast('Geçersiz JSON.', 'error');
  }
});

/* ---------------- Durum ekranı yazımı (HER ŞEY pos ekranında) ---------------- */
function durumYaz(stage, msg){
  screenStage.textContent = stage || '';
  if(msg !== undefined) screenMsg.textContent = msg;
}
function baglantiRozetiGuncelle(durum){
  connDot.className = 'conn-dot ' + durum; // 'off' | 'connecting' | 'on'
  if(durum === 'on'){ connText.textContent = 'Bağlı — Ana Merkez'; }
  else if(durum === 'connecting'){ connText.textContent = 'Bağlanıyor…'; }
  else{ connText.textContent = 'Bağlı değil'; }
}

/* ---------------- Bağlan / Bağlantıyı Kes ---------------- */
function baglan(){
  if(baglantiAktif) return;
  const ayar = ayarlariYukle();
  if(!ayar || !ayar.config || !ayar.oturumKodu){
    durumYaz('YAPILANDIRMA YOK', 'Ayarlar bölümünden Firebase bilgisi girin.');
    return;
  }
  baglantiAktif = true;
  btnBaglan.classList.add('hidden');
  btnBaglantiKes.classList.remove('hidden');
  baglantiRozetiGuncelle('connecting');
  durumYaz('BAĞLANIYOR…', 'Ana merkeze bağlanılıyor, lütfen bekleyin…');
  SES.baglaniyor();

  if(typeof firebase === 'undefined'){
    baglantiHatasi('Firebase kütüphanesi yüklenemedi. İnternet bağlantınızı kontrol edin.');
    return;
  }
  try{
    if(!firebase.apps || firebase.apps.length === 0) firebase.initializeApp(ayar.config);
    firebaseDB = firebase.database();
    firebaseHazir = true;

    // bağlantı gerçekten kurulana kadar ekranda "bağlanıyor" kalsın
    const connRef = firebaseDB.ref('.info/connected');
    const connHandler = connRef.on('value', (snap)=>{
      if(!baglantiAktif) return;
      if(snap.val() === true){
        connRef.off('value', connHandler);
        baglantiKuruldu();
      }
    });
    // 8 saniyede kurulmazsa ekranda uyarı göster ama denemeyi kesme
    setTimeout(()=>{
      if(baglantiAktif && connDot.classList.contains('connecting')){
        durumYaz('BAĞLANIYOR…', 'Bağlantı sürüyor, ağınız yavaş olabilir…');
      }
    }, 8000);
  }catch(e){
    baglantiHatasi('Bağlantı kurulamadı: ' + e.message);
  }
}

function baglantiKuruldu(){
  if(!baglantiAktif) return;
  baglantiRozetiGuncelle('on');
  durumYaz('POS HAZIR', 'Ana merkez bağlantısı açık. Yeni ödeme isteği otomatik burada görünecek.');
  SES.bagliOldu();
  dinlemeyiBaslat();
}

function baglantiHatasi(mesaj){
  baglantiAktif = false;
  firebaseHazir = false;
  btnBaglan.classList.remove('hidden');
  btnBaglantiKes.classList.add('hidden');
  baglantiRozetiGuncelle('off');
  durumYaz('BAĞLANTI HATASI', mesaj);
  SES.hata();
}

function baglantiyiKes(){
  if(dinleyiciRef && dinleyiciFn) dinleyiciRef.off('value', dinleyiciFn);
  dinleyiciRef = null; dinleyiciFn = null;
  baglantiAktif = false;
  firebaseHazir = false;
  mevcutIstek = null;
  pinTimerTemizle();
  btnBaglan.classList.remove('hidden');
  btnBaglantiKes.classList.add('hidden');
  baglantiRozetiGuncelle('off');
  contactlessPad.classList.add('hidden');
  pinDots.classList.add('hidden');
  keypad.querySelectorAll('button').forEach(b=>b.disabled=true);
  screenAmount.textContent = '0,00 ₺';
  durumYaz('BAĞLANTI KESİLDİ', 'Yeniden başlamak için "Bağlan" tuşuna basın.');
  SES.baglantiKesildi();
}

btnBaglan.addEventListener('click', baglan);
btnBaglantiKes.addEventListener('click', baglantiyiKes);

/* ---------------- Ana Merkez'den gelen istekleri dinleme ---------------- */
function dinlemeyiBaslat(){
  if(!firebaseHazir) return;
  dinleyiciRef = firebaseDB.ref(yolOlustur('istek'));
  dinleyiciFn = dinleyiciRef.on('value', (snap)=>{
    const istek = snap.val();
    if(!istek || istek.id === sonIslenenIstekId) return;
    sonIslenenIstekId = istek.id;
    yeniIstekGeldi(istek);
  });
}

/* ---------------- Yeni ödeme isteği geldiğinde: önce "VERİ OKUNUYOR", sonra tutar ---------------- */
function yeniIstekGeldi(istek){
  mevcutIstek = istek;
  islemBitti = false; odemeBasarili = false; pin = '';
  fisiGizle();
  contactlessPad.classList.add('hidden');
  pinDots.classList.add('hidden');
  keypad.querySelectorAll('button').forEach(b=>b.disabled=true);
  screenAmount.textContent = '';

  durumYaz('VERİ OKUNUYOR…', 'Ana merkezden ödeme bilgisi alınıyor.');
  SES.veriGeldi();

  // kısa bir "okunuyor" beklemesi -> sonra tutarı göster (istenen davranış)
  setTimeout(()=>{
    if(!mevcutIstek || mevcutIstek.id !== istek.id) return;
    tutariGosterVeBekle(istek);
  }, 1400);
}

function tutariGosterVeBekle(istek){
  durumYaz('TUTAR', undefined);
  screenAmount.textContent = paraFormat(istek.tutar);
  screenMsg.textContent = 'Kartı ekrana dokundurun (temassız) veya şifre ile devam edin.';
  contactlessPad.classList.remove('hidden');
  pinDots.classList.add('hidden');
  keypad.querySelectorAll('button').forEach(b=>b.disabled=false);
  pin = ''; pinNoktalariniGuncelle();
  pinTimerTemizle();
  pinTimer = setTimeout(sifreEkraninaGec, 12000);
}

function pinTimerTemizle(){ if(pinTimer){ clearTimeout(pinTimer); pinTimer=null; } }

function sifreEkraninaGec(){
  if(islemBitti || !mevcutIstek) return;
  pinTimerTemizle();
  durumYaz('ŞİFRE GİRİN', 'Kart şifresini tuş takımından girin.');
  contactlessPad.classList.add('hidden');
  pinDots.classList.remove('hidden');
  pin = ''; pinNoktalariniGuncelle();
}

function pinNoktalariniGuncelle(){
  pinDots.querySelectorAll('span').forEach((el,i)=> el.classList.toggle('filled', i<pin.length));
}

/* Temassız dokunma */
contactlessPad.addEventListener('click', ()=>{
  if(islemBitti || !mevcutIstek) return;
  pinTimerTemizle();
  odemeBaslat('TEMASSIZ');
});

/* Tuş takımı */
keypad.addEventListener('click', (e)=>{
  const b = e.target.closest('button');
  if(!b || islemBitti || !mevcutIstek) return;
  const k = b.dataset.k;
  SES.tus();
  if(k === 'C'){ pin = pin.slice(0,-1); pinNoktalariniGuncelle(); return; }
  if(k === 'OK'){
    if(pinDots.classList.contains('hidden')){
      // henüz şifre ekranına geçilmediyse OK -> direkt şifre ekranına geç
      sifreEkraninaGec();
      return;
    }
    if(pin.length < 4){ screenMsg.textContent = 'En az 4 haneli şifre girin.'; return; }
    odemeBaslat('ŞİFRE');
    return;
  }
  if(/^\d$/.test(k) && pin.length < 4){
    pin += k; pinNoktalariniGuncelle();
    if(pinDots.classList.contains('hidden')){
      pinDots.classList.remove('hidden');
      contactlessPad.classList.add('hidden');
    }
  }
});

/* ---------------- Ödeme akışı: hep POS ekranında yazan durum ---------------- */
function odemeBaslat(yontem){
  if(islemBitti || !mevcutIstek) return;
  islemBitti = true;
  pinTimerTemizle();
  contactlessPad.classList.add('hidden');
  keypad.querySelectorAll('button').forEach(b=>b.disabled=true);
  durumYaz('İŞLEM YAPILIYOR…', yontem === 'TEMASSIZ' ? 'Temassız ödeme işleniyor, kartı çekmeyin.' : 'Lütfen bekleyin, ödeme onaylanıyor.');
  SES.islemBasladi();

  setTimeout(()=>{
    const basarisizOlasilik = 0.08;
    const basarili = Math.random() > basarisizOlasilik;
    sonucGoster(basarili, mevcutIstek, yontem);
  }, 1300);
}

function sonucGoster(basarili, istek, yontem){
  odemeBasarili = basarili;
  keypad.querySelectorAll('button').forEach(b=>b.disabled=true);

  if(!basarili){
    durumYaz('❌ YETERSİZ BAKİYE', 'Kartta yeterli bakiye bulunamadı. İşlem reddedildi.');
    SES.hata();
    sonucuAnaMerkezeGonder(istek, false, yontem);
    setTimeout(()=> islemiSifirla(), 3000);
    return;
  }

  durumYaz('✅ ONAYLANDI', 'Ödeme onaylandı. Fiş yazdırılıyor…');
  SES.onay();
  sonucuAnaMerkezeGonder(istek, true, yontem);
  fisiYazdir(istek, yontem);
}

function sonucuAnaMerkezeGonder(istek, basarili, yontem){
  if(!firebaseHazir) return;
  try{
    firebaseDB.ref(yolOlustur('sonuc')).set({
      id: istek.id,
      basarili,
      yontem,
      zaman: Date.now()
    });
  }catch(e){ /* bağlantı koparsa sessizce geç, ekran zaten durumu gösteriyor */ }
}

function islemiSifirla(){
  mevcutIstek = null;
  islemBitti = false; odemeBasarili = false; pin='';
  fisiGizle();
  contactlessPad.classList.add('hidden');
  pinDots.classList.add('hidden');
  screenAmount.textContent = '0,00 ₺';
  if(baglantiAktif){
    durumYaz('POS HAZIR', 'Ana merkez bağlantısı açık. Yeni ödeme isteği otomatik burada görünecek.');
  }else{
    durumYaz('BAĞLANTI BEKLENİYOR', 'Ana merkeze bağlanmak için yukarıdan "Bağlan" tuşuna basın.');
  }
}

/* ---------------- Fiş yazdırma + kaydırıp koparma ---------------- */
function fisiYazdir(istek, yontem){
  const simdi = new Date().toLocaleString('tr-TR');
  receipt.innerHTML = `
    <div class="r-title">ANA MERKEZ ÖDEME FİŞİ</div>
    <div class="r-date">${simdi}</div>
    <div class="r-row"><span>İşlem No</span><span>#${String(istek.id).slice(-6)}</span></div>
    <div class="r-row"><span>Bağlam</span><span>${(istek.baglam||'ödeme').toUpperCase()}</span></div>
    <div class="r-row r-total"><span>TOPLAM</span><span>${paraFormat(istek.tutar)}</span></div>
    <div class="r-ok">${yontem==='TEMASSIZ' ? 'TEMASSIZ KART' : 'KART'} İLE ÖDENDİ ✔</div>
    <div class="r-hint">👉 Sağa kaydırıp koparın</div>
  `;
  receipt.classList.remove('hidden','tearing');
  receipt.style.transform = 'translateX(-50%)';
  requestAnimationFrame(()=> receipt.classList.add('printing'));
  SES.yazdirma();
}
function fisiGizle(){
  receipt.classList.add('hidden');
  receipt.classList.remove('printing','tearing');
  receipt.innerHTML = '';
  receipt.style.transform = 'translateX(-50%)';
}
receipt.addEventListener('pointerdown', (e)=>{
  if(!odemeBasarili) return;
  fisSuruklemeAktif = true; fisBaslangicX = e.clientX; fisX = 0;
  receipt.setPointerCapture?.(e.pointerId);
});
receipt.addEventListener('pointermove', (e)=>{
  if(!fisSuruklemeAktif) return;
  fisX = Math.max(0, e.clientX - fisBaslangicX);
  receipt.style.transform = `translateX(calc(-50% + ${fisX}px)) rotate(${Math.min(10, fisX/24)}deg)`;
});
receipt.addEventListener('pointerup', ()=>{
  if(!fisSuruklemeAktif) return;
  fisSuruklemeAktif = false;
  if(fisX > receipt.offsetWidth * 0.4){
    receipt.classList.add('tearing');
    receipt.style.transform = `translateX(140vw) rotate(18deg)`;
    SES.yirtma();
    setTimeout(()=>{ islemiSifirla(); }, 380);
  }else{
    receipt.style.transform = 'translateX(-50%) rotate(0)';
  }
});
receipt.addEventListener('pointercancel', ()=>{
  fisSuruklemeAktif = false;
  receipt.style.transform = 'translateX(-50%) rotate(0)';
});

/* ---------------- Başlangıç durumu ---------------- */
baglantiRozetiGuncelle('off');
durumYaz('BAĞLANTI BEKLENİYOR', 'Ana merkeze bağlanmak için yukarıdan "Bağlan" tuşuna basın.');
keypad.querySelectorAll('button').forEach(b=>b.disabled=true);
