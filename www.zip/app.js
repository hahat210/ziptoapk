/* ===================== YARDIMCI FONKSİYONLAR ===================== */
const FOTO_DB='HastaneFotoDB', FOTO_STORE='fotolar';
let fotoCache={};
function fotoDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(FOTO_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(FOTO_STORE))r.result.createObjectStore(FOTO_STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function fotoKaydet(tc,data){if(!data)return;fotoCache[tc]=data;try{const db=await fotoDB();await new Promise((res,rej)=>{const tx=db.transaction(FOTO_STORE,'readwrite');tx.objectStore(FOTO_STORE).put(data,String(tc));tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close()}catch(e){}}
async function fotoGetir(tc){if(fotoCache[tc])return fotoCache[tc];try{const db=await fotoDB();const v=await new Promise((res,rej)=>{const tx=db.transaction(FOTO_STORE,'readonly');const q=tx.objectStore(FOTO_STORE).get(String(tc));q.onsuccess=()=>res(q.result||'');q.onerror=()=>rej(q.error)});db.close();if(v)fotoCache[tc]=v;return v}catch(e){return ''}}
function loadHastalar(){try{return JSON.parse(localStorage.getItem('hastane_hastalar')||'{}')}catch(e){return {}}}
function saveHastalar(d){try{const meta=JSON.parse(JSON.stringify(d));Object.keys(meta).forEach(tc=>delete meta[tc].foto);localStorage.setItem('hastane_hastalar',JSON.stringify(meta));return true}catch(e){toast('Hasta kayıt alanı dolu. Fotoğraflar cihazın geniş depolamasında tutuluyor.','error');return false}}
function fotoDataSikistir(dataUrl,maxW=420,maxH=560,quality=0.62){return new Promise(resolve=>{if(!dataUrl||!dataUrl.startsWith('data:image/'))return resolve(dataUrl);const img=new Image();img.onload=()=>{let w=img.naturalWidth||img.width||maxW,h=img.naturalHeight||img.height||maxH;const oran=Math.min(1,maxW/w,maxH/h);w=Math.max(1,Math.round(w*oran));h=Math.max(1,Math.round(h*oran));const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d',{alpha:false}).drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',quality))};img.onerror=()=>resolve(dataUrl);img.src=dataUrl})}
async function hastalariFotolariOptimizeEt(){const hastalar=loadHastalar();for(const tc of Object.keys(hastalar)){if(hastalar[tc]?.foto?.startsWith('data:image/')){await fotoKaydet(tc,await fotoDataSikistir(hastalar[tc].foto));delete hastalar[tc].foto}}saveHastalar(hastalar)}
function loadStok(){ return JSON.parse(localStorage.getItem('hastane_stok') || '{}'); }
function saveStok(d){ localStorage.setItem('hastane_stok', JSON.stringify(d)); }

function simdi(){
  return new Date().toLocaleString('tr-TR', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
}
function paraFormat(n){ return (Number(n)||0).toFixed(2).replace('.', ',') + ' ₺'; }

function toast(msg, tip){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast' + (tip ? ' ' + tip : '');
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=> el.classList.add('hidden'), 2600);
}

function beep(freq=1250, duration=110){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = freq;
    osc.type = 'square';
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration/1000);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration/1000 + 0.02);
  }catch(e){ /* ses desteklenmiyor olabilir, sorun değil */ }
}

/* ===================== SEKME (TAB) YÖNETİMİ ===================== */
const pageTitles = { kayit:'Hasta Kayıt', muayene:'Muayene', stok:'İlaç Satın Al', kasiyer:'Eczane Kasiyer', borclar:'Borçlar', banka:'Banka Hesabı' };

function sekmeyeGec(tab){
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  document.getElementById('pageTitle').textContent = pageTitles[tab];
  if(tab === 'muayene') muayeneStokSelectDoldur();
  if(tab === 'stok'){ katalogKartlariniRenderla(); sepetiRenderla(); siparislerimiRenderla(); stokTablosunuRenderla(); }
  if(tab === 'borclar') borclarSekmesiniRenderla();
  if(tab === 'banka') bankaSekmesiniRenderla();
}

document.querySelectorAll('.nav-btn').forEach(btn=>{
  btn.addEventListener('click', ()=> sekmeyeGec(btn.dataset.tab));
});

/* Saat */
function saatiGuncelle(){
  document.getElementById('clock').textContent = new Date().toLocaleTimeString('tr-TR');
}
setInterval(saatiGuncelle, 1000); saatiGuncelle();

/* ===================== KAMERA (yalnızca hasta fotoğrafı için) ===================== */
const cameraModal = document.getElementById('cameraModal');
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const cameraStatus = document.getElementById('cameraStatus');
const modalActions = document.getElementById('modalActions');
let currentStream = null;
let aktifKamera = 'user'; // user = ön kamera, environment = arka kamera

async function kameraAc(yenidenBaslat=false){
  if(yenidenBaslat && currentStream){ currentStream.getTracks().forEach(t=>t.stop()); currentStream = null; }
  cameraStatus.textContent = aktifKamera === 'environment' ? 'Arka kamera açılıyor…' : 'Ön kamera açılıyor…';
  try{
    currentStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: aktifKamera } },
      audio: false
    });
    video.srcObject = currentStream;
    cameraStatus.textContent = aktifKamera === 'environment' ? 'Arka kamera hazır.' : 'Ön kamera hazır.';
    return true;
  }catch(e){
    cameraStatus.textContent = '⚠️ Kameraya erişilemedi. Tarayıcı/uygulama izinlerini kontrol edin.';
    return false;
  }
}

function kameraKapat(){
  if(currentStream){ currentStream.getTracks().forEach(t=>t.stop()); currentStream = null; }
  video.srcObject = null;
  cameraModal.classList.add('hidden');
  modalActions.innerHTML = '';
}
document.getElementById('btnCameraClose').addEventListener('click', kameraKapat);

function fotoCekModuAc(onCaptured){
  document.getElementById('cameraModalTitle').textContent = '📷 Fotoğraf Çek';
  cameraModal.classList.remove('hidden');
  modalActions.innerHTML = '';
  const cekBtn = document.createElement('button');
  cekBtn.className = 'btn btn-primary'; cekBtn.textContent = '📸 Çek';
  const kameraDegistirBtn = document.createElement('button');
  kameraDegistirBtn.className = 'btn btn-ghost';
  kameraDegistirBtn.textContent = aktifKamera === 'environment' ? '🔄 Ön Kameraya Geç' : '🔄 Arka Kameraya Geç';
  kameraDegistirBtn.addEventListener('click', async ()=>{
    aktifKamera = aktifKamera === 'user' ? 'environment' : 'user';
    kameraDegistirBtn.disabled = true;
    await kameraAc(true);
    kameraDegistirBtn.textContent = aktifKamera === 'environment' ? '🔄 Ön Kameraya Geç' : '🔄 Arka Kameraya Geç';
    kameraDegistirBtn.disabled = false;
  });
  const vazgecBtn = document.createElement('button');
  vazgecBtn.className = 'btn btn-ghost'; vazgecBtn.textContent = 'Vazgeç';
  vazgecBtn.addEventListener('click', kameraKapat);
  cekBtn.addEventListener('click', async ()=>{
    const vw = video.videoWidth || 480;
    const vh = video.videoHeight || 360;
    const oran = Math.min(1, 360 / vw, 480 / vh);
    canvas.width = Math.max(1, Math.round(vw * oran));
    canvas.height = Math.max(1, Math.round(vh * oran));
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.58);
    kameraKapat();
    onCaptured(dataUrl);
  });
  modalActions.appendChild(vazgecBtn);
  modalActions.appendChild(kameraDegistirBtn);
  modalActions.appendChild(cekBtn);
  kameraAc();
}

/* ===================== HASTA KAYIT ===================== */
let kayitFotoData = '';

document.getElementById('btnKameraCek').addEventListener('click', ()=>{
  fotoCekModuAc(dataUrl=>{
    kayitFotoData = dataUrl;
    document.getElementById('kayitFotoPreview').innerHTML = `<img src="${dataUrl}">`;
    idKartOnizlemeGuncelle();
  });
});
document.getElementById('btnDosyaSec').addEventListener('click', ()=>{
  document.getElementById('kayitFotoInput').click();
});
document.getElementById('kayitFotoInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async ()=>{
    kayitFotoData = await fotoDataSikistir(reader.result);
    document.getElementById('kayitFotoPreview').innerHTML = `<img src="${kayitFotoData}">`;
    idKartOnizlemeGuncelle();
  };
  reader.readAsDataURL(file);
});

document.getElementById('kayitAd').addEventListener('input', idKartOnizlemeGuncelle);
document.getElementById('kayitTc').addEventListener('input', idKartOnizlemeGuncelle);

function idKartOnizlemeGuncelle(){
  const ad = document.getElementById('kayitAd').value.trim() || '— — —';
  const tc = document.getElementById('kayitTc').value.trim() || '—';
  const kart = document.getElementById('idCardPreview');
  kart.querySelector('.id-card-name').textContent = ad;
  document.getElementById('idCardTc').textContent = tc;
  document.getElementById('idCardTarih').textContent = '—';
  const fotoBox = kart.querySelector('.id-card-photo');
  fotoBox.innerHTML = kayitFotoData ? `<img src="${kayitFotoData}">` : '<span>FOTO</span>';
}

function kayitFormunuTemizle(){
  document.getElementById('kayitAd').value = '';
  document.getElementById('kayitTc').value = '';
  kayitFotoData = '';
  document.getElementById('kayitFotoPreview').innerHTML = '<span>Fotoğraf Yok</span>';
  idKartOnizlemeGuncelle();
}

function kayitliHastalariRenderla(){
  const hastalar = loadHastalar();
  const tcler = Object.keys(hastalar);
  document.getElementById('hastaSayisi').textContent = tcler.length;
  const ul = document.getElementById('kayitliHastalarList');
  ul.innerHTML = '';
  if(tcler.length === 0){ ul.innerHTML = '<li class="empty">Henüz hasta kaydı yok</li>'; return; }
  [...tcler].reverse().forEach(tc=>{
    const h = hastalar[tc];
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `<span>👤 ${h.ad}</span><span style="color:var(--text-soft);font-size:11.5px;">${h.tc}</span>`;
    ul.appendChild(li);
  });
}

document.getElementById('btnHastaKaydet').addEventListener('click', async ()=>{
  const ad = document.getElementById('kayitAd').value.trim();
  const tc = document.getElementById('kayitTc').value.trim();
  if(!ad || tc.length !== 11 || !/^\d+$/.test(tc)){
    toast('Ad Soyad girin ve 11 haneli geçerli bir T.C. No yazın.', 'error'); return;
  }
  if(!kayitFotoData){
    toast('Lütfen bir fotoğraf ekleyin (kamera veya dosya).', 'error'); return;
  }
  const hastalar = loadHastalar();
  if(hastalar[tc]){
    toast('Bu T.C. No ile kayıtlı bir hasta zaten var.', 'error'); return;
  }
  const foto = kayitFotoData ? await fotoDataSikistir(kayitFotoData) : '';
  hastalar[tc] = { ad, tc, kayitTarihi: simdi(), muayeneler: [] };
  if(foto) await fotoKaydet(tc,foto);
  if(!saveHastalar(hastalar)) return;
  toast(`${ad} başarıyla kaydedildi. (Toplam ${Object.keys(hastalar).length} hasta)`, 'success');
  if(navigator.vibrate) navigator.vibrate(30);
  kayitFormunuTemizle();
  kayitliHastalariRenderla();
hastaSecimListesiniDoldur();
});

/* ===================== MUAYENE ===================== */
let secilenHastaTc = null;
let aktifRecete = [];

function hastaSecimListesiniDoldur(inputId){
  const list=document.getElementById('kayitliHastaSecenekleri'); if(!list)return;
  const hastalar=loadHastalar();
  list.innerHTML=Object.values(hastalar).map(h=>`<option value="${h.tc}" label="${h.ad} — ${h.tc}"></option>`).join('');
}
function hastaSecildi(inputId, callback){
  const v=document.getElementById(inputId).value.trim();
  callback(v);
}
document.getElementById('btnHastaBul').addEventListener('click', ()=>{
  const tc = document.getElementById('muayeneTcSorgu').value.trim();
  const hastalar = loadHastalar();
  const hasta = hastalar[tc];
  if(!hasta){ toast('Bu T.C. ile kayıtlı hasta bulunamadı.', 'error'); return; }
  secilenHastaTc = tc;
  aktifRecete = [];
  document.getElementById('muayeneHastaAd').textContent = hasta.ad;
  document.getElementById('muayeneHastaTc').textContent = hasta.tc;
  const fotoBox = document.getElementById('muayeneHastaKart').querySelector('.id-card-photo');
  fotoBox.innerHTML = '<span>FOTO</span>';
  fotoGetir(tc).then(f=>{ if(f) fotoBox.innerHTML=`<img src="${f}">`; });
  document.getElementById('muayeneNot').value = '';
  gecmisMuayeneleriDoldur(hasta);
  receteListesiRenderla();
  muayeneStokSelectDoldur();
});

function gecmisMuayeneleriDoldur(hasta){
  const ul = document.getElementById('muayeneGecmisList');
  ul.innerHTML = '';
  if(!hasta.muayeneler || hasta.muayeneler.length === 0){
    ul.innerHTML = '<li class="empty">Geçmiş muayene yok</li>'; return;
  }
  const siraliListe = hasta.muayeneler.map((m, i)=>({m, i})).reverse();
  siraliListe.forEach(({m})=>{
    const li = document.createElement('li');
    const receteHtml = (m.receteler && m.receteler.length > 0)
      ? m.receteler.map(ad=>`<div>💊 ${ad}</div>`).join('')
      : '<div>Reçete verilmedi</div>';
    const odemeEtiket = (m.receteler && m.receteler.length > 0)
      ? (m.odendiMi ? '<span class="tag-ok">✔ ÖDENDİ</span>' : '<span class="tag-wait">ÖDENMEDİ</span>')
      : '';
    li.innerHTML = `
      <div class="gecmis-baslik">
        <span>${m.tarih}</span>${odemeEtiket}
      </div>
      <div class="gecmis-detay hidden">
        <div style="white-space:pre-wrap;margin-bottom:6px;">${(m.not||'').replace(/</g,'&lt;') || '<i>(Not girilmedi)</i>'}</div>
        ${receteHtml}
      </div>
    `;
    li.querySelector('.gecmis-baslik').addEventListener('click', ()=>{
      li.querySelector('.gecmis-detay').classList.toggle('hidden');
      document.getElementById('muayeneNot').value = m.not || '';
    });
    ul.appendChild(li);
  });
}

function muayeneStokSelectDoldur(){
  const sel = document.getElementById('muayeneIlacSecim');
  const stok = loadStok();
  sel.innerHTML = '';
  const isimler = Object.keys(stok);
  if(isimler.length === 0){ sel.innerHTML = '<option value="">Stokta ilaç yok</option>'; return; }
  isimler.forEach(ad=>{
    const opt = document.createElement('option');
    opt.value = ad;
    opt.textContent = `${ad} (${stok[ad].adet} adet)`;
    sel.appendChild(opt);
  });
}

document.getElementById('btnIlacRecetele').addEventListener('click', ()=>{
  if(!secilenHastaTc){ toast('Önce bir hasta bulun.', 'error'); return; }
  const ad = document.getElementById('muayeneIlacSecim').value;
  if(!ad){ toast('Stokta ilaç yok.', 'error'); return; }
  const stok = loadStok();
  if(!stok[ad] || stok[ad].adet <= 0){ toast(`${ad} stokta yok.`, 'error'); return; }
  stok[ad].adet -= 1;
  saveStok(stok);
  aktifRecete.push(ad);
  receteListesiRenderla();
  muayeneStokSelectDoldur();
  stokTablosunuRenderla();
  toast(`${ad} reçeteye eklendi, stoktan düşüldü.`);
});

function receteListesiRenderla(){
  const ul = document.getElementById('muayeneReceteList');
  ul.innerHTML = '';
  if(aktifRecete.length === 0){ ul.innerHTML = '<li class="empty">Reçeteye ilaç eklenmedi</li>'; return; }
  aktifRecete.forEach((ad, idx)=>{
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `<span>💊 ${ad}</span><button class="okut-btn" style="background:var(--ios-red);">✕ İptal</button>`;
    li.querySelector('button').addEventListener('click', ()=>{
      const stok = loadStok();
      if(stok[ad]) stok[ad].adet += 1;
      saveStok(stok);
      aktifRecete.splice(idx, 1);
      receteListesiRenderla();
      muayeneStokSelectDoldur();
      stokTablosunuRenderla();
      toast(`${ad} reçeteden çıkarıldı, stoğa geri eklendi.`);
    });
    ul.appendChild(li);
  });
}

document.getElementById('btnMuayeneKaydet').addEventListener('click', ()=>{
  if(!secilenHastaTc){ toast('Önce bir hasta bulun.', 'error'); return; }
  const not = document.getElementById('muayeneNot').value.trim();
  if(!not && aktifRecete.length === 0){ toast('Not yazın veya en az bir ilaç reçete edin.', 'error'); return; }
  const hastalar = loadHastalar();
  const hasta = hastalar[secilenHastaTc];
  hasta.muayeneler.push({
    tarih: simdi(),
    not,
    receteler: [...aktifRecete],
    odendiMi: aktifRecete.length === 0
  });
  saveHastalar(hastalar);
  toast('Muayene arşive eklendi.', 'success');
  aktifRecete = [];
  receteListesiRenderla();
  gecmisMuayeneleriDoldur(hasta);
  document.getElementById('muayeneNot').value = '';
});

/* ===================== BANKA HESABI ===================== */
const FAIZ_ORANI = 0.05; // günlük %5 faiz (ödenmemiş kredi borcuna işler)

function loadBanka(){
  let b = JSON.parse(localStorage.getItem('hastane_banka') || 'null');
  if(!b){ b = { bakiye: 500, krediBorcu: 0, sonFaizZamani: Date.now() }; localStorage.setItem('hastane_banka', JSON.stringify(b)); }
  return b;
}
function saveBanka(b){ localStorage.setItem('hastane_banka', JSON.stringify(b)); }

function bankaFaiziGuncelle(){
  const b = loadBanka();
  if(b.krediBorcu <= 0){ b.sonFaizZamani = Date.now(); saveBanka(b); return; }
  const gecenGun = Math.floor((Date.now() - b.sonFaizZamani) / (24*60*60*1000));
  if(gecenGun >= 1){
    for(let i=0;i<gecenGun;i++){ b.krediBorcu = Math.round(b.krediBorcu * (1 + FAIZ_ORANI) * 100) / 100; }
    b.sonFaizZamani += gecenGun * 24*60*60*1000;
    saveBanka(b);
    toast(`Ödenmemiş kredi borcuna ${gecenGun} günlük faiz işledi.`, 'error');
  }
}

function bankadanOde(tutar){
  const b = loadBanka();
  if(b.bakiye < tutar) return false;
  b.bakiye = Math.round((b.bakiye - tutar) * 100) / 100;
  saveBanka(b);
  bankaSekmesiniRenderla();
  return true;
}

document.getElementById('btnKrediCek').addEventListener('click', ()=>{
  const tutar = parseFloat(document.getElementById('krediTutar').value);
  if(isNaN(tutar) || tutar <= 0){ toast('Geçerli bir tutar girin.', 'error'); return; }
  const b = loadBanka();
  b.bakiye = Math.round((b.bakiye + tutar) * 100) / 100;
  b.krediBorcu = Math.round((b.krediBorcu + tutar) * 100) / 100;
  saveBanka(b);
  document.getElementById('krediTutar').value = '';
  toast(`${paraFormat(tutar)} kredi çekildi. Ödemezsen her gün %${FAIZ_ORANI*100} faiz işler!`, 'success');
  bankaSekmesiniRenderla();
});

document.getElementById('btnKrediOde').addEventListener('click', ()=>{
  const tutar = parseFloat(document.getElementById('krediOdeTutar').value);
  if(isNaN(tutar) || tutar <= 0){ toast('Geçerli bir tutar girin.', 'error'); return; }
  const b = loadBanka();
  if(b.bakiye < tutar){ toast('Bakiyen yetersiz.', 'error'); return; }
  const odenecek = Math.min(tutar, b.krediBorcu);
  b.bakiye = Math.round((b.bakiye - odenecek) * 100) / 100;
  b.krediBorcu = Math.round((b.krediBorcu - odenecek) * 100) / 100;
  saveBanka(b);
  document.getElementById('krediOdeTutar').value = '';
  toast(`${paraFormat(odenecek)} kredi borcuna ödendi.`, 'success');
  bankaSekmesiniRenderla();
});

function bankaSekmesiniRenderla(){
  bankaFaiziGuncelle();
  const b = loadBanka();
  document.getElementById('bankaBakiye').textContent = paraFormat(b.bakiye);
  document.getElementById('bankaKrediBorcu').textContent = paraFormat(b.krediBorcu);
  document.getElementById('btnKrediOde').disabled = b.krediBorcu <= 0;
}

/* ===================== İLAÇ SATIN ALMA (katalog + sepet + kargo) ===================== */
const ILAC_KATALOG = [
  {ad:'Parol', kategori:'agrikesici', fiyat:15},
  {ad:'Aspirin', kategori:'agrikesici', fiyat:12},
  {ad:'İbuprofen', kategori:'agrikesici', fiyat:18},
  {ad:'Majezik', kategori:'agrikesici', fiyat:22},
  {ad:'Apranax', kategori:'agrikesici', fiyat:20},
  {ad:'Öksürük Şurubu', kategori:'surup', fiyat:25},
  {ad:'Ateş Düşürücü Şurup', kategori:'surup', fiyat:20},
  {ad:'Vitamin C Şurubu', kategori:'surup', fiyat:18},
  {ad:'Mide Şurubu', kategori:'surup', fiyat:16},
  {ad:'Göz Damlası', kategori:'damla', fiyat:30},
  {ad:'Burun Damlası', kategori:'damla', fiyat:14},
  {ad:'Kulak Damlası', kategori:'damla', fiyat:17},
  {ad:'Vitamin D Damlası', kategori:'damla', fiyat:35},
  {ad:'Ağrı Kesici İğne', kategori:'igne', fiyat:40},
  {ad:'Antibiyotik İğnesi', kategori:'igne', fiyat:45},
  {ad:'Serum İğnesi', kategori:'igne', fiyat:38},
  {ad:'B12 İğnesi', kategori:'igne', fiyat:33},
  {ad:'Nadir Hastalık İlacı', kategori:'ozel', fiyat:180},
  {ad:'İthal Özel Serum', kategori:'ozel', fiyat:150},
  {ad:'Fingiro Süper İlaç', kategori:'fingiro', fiyat:250},
];
const KATEGORI_LIMIT = { agrikesici:7, surup:7, damla:4, igne:Infinity, ozel:3, fingiro:1 };
const KATEGORI_TESLIM = { agrikesici:[3,4], surup:[3,4], damla:[3,4], igne:[3,4], ozel:[6,7], fingiro:[5,6] };
const KATEGORI_ETIKET = { agrikesici:'Ağrı Kesici', surup:'Şurup', damla:'Damla', igne:'İğne', ozel:'Özel İstek', fingiro:'Fingiro' };
// Oyun zamanı: 1 oyun saati = 10 gerçek saniye
const OYUN_SAATI_MS = 10 * 1000;

let satinalmaSepeti = []; // {ad, adet}

function loadSiparisler(){ return JSON.parse(localStorage.getItem('hastane_siparisler') || '[]'); }
function saveSiparisler(d){ localStorage.setItem('hastane_siparisler', JSON.stringify(d)); }

function siparisBekleyenAdet(ad){
  return loadSiparisler().filter(s=>s.durum==='yolda').reduce((toplam,s)=>{
    const k = s.kalemler.find(x=>x.ad===ad);
    return toplam + (k ? k.adet : 0);
  }, 0);
}

function katalogKartlariniRenderla(){
  const grid = document.getElementById('katalogGrid');
  grid.innerHTML = '';
  ILAC_KATALOG.forEach(urun=>{
    const stok = loadStok();
    const mevcut = (stok[urun.ad] && stok[urun.ad].adet) || 0;
    const bekleyen = siparisBekleyenAdet(urun.ad);
    const sepette = (satinalmaSepeti.find(x=>x.ad===urun.ad) || {adet:0}).adet;
    const limit = KATEGORI_LIMIT[urun.kategori];
    const doldumu = (mevcut + bekleyen + sepette) >= limit;
    const div = document.createElement('div');
    div.className = 'katalog-kart';
    div.innerHTML = `
      <div class="katalog-kategori">${KATEGORI_ETIKET[urun.kategori]}</div>
      <div class="katalog-ad">${urun.ad}</div>
      <div class="katalog-fiyat">${paraFormat(urun.fiyat)}</div>
      <div class="katalog-stok">Stok: ${mevcut}${bekleyen>0?` · Yolda: ${bekleyen}`:''}</div>
      <button class="btn btn-secondary btn-block" ${doldumu?'disabled':''}>${doldumu?'Limit Doldu':'🛒 Sepete Ekle'}</button>
    `;
    div.querySelector('button').addEventListener('click', ()=> sepeteEkle(urun.ad));
    grid.appendChild(div);
  });
}

function sepeteEkle(ad){
  const urun = ILAC_KATALOG.find(x=>x.ad===ad);
  if(!urun) return;
  const stok = loadStok();
  const mevcut = (stok[ad] && stok[ad].adet) || 0;
  const bekleyen = siparisBekleyenAdet(ad);
  const satir = satinalmaSepeti.find(x=>x.ad===ad);
  const sepette = satir ? satir.adet : 0;
  const limit = KATEGORI_LIMIT[urun.kategori];
  if(mevcut + bekleyen + sepette + 1 > limit){
    toast(`${ad} için sipariş limiti (${limit===Infinity?'sınırsız':limit} adet) doldu.`, 'error'); return;
  }
  if(satir) satir.adet++; else satinalmaSepeti.push({ ad, adet: 1 });
  sepetiRenderla();
  katalogKartlariniRenderla();
}

function sepettenCikar(ad){
  const satir = satinalmaSepeti.find(x=>x.ad===ad);
  if(!satir) return;
  satir.adet--;
  if(satir.adet <= 0) satinalmaSepeti = satinalmaSepeti.filter(x=>x.ad!==ad);
  sepetiRenderla();
  katalogKartlariniRenderla();
}

function sepetToplamTutar(){
  return satinalmaSepeti.reduce((s,x)=>{
    const urun = ILAC_KATALOG.find(u=>u.ad===x.ad);
    return s + (urun ? urun.fiyat * x.adet : 0);
  }, 0);
}

function sepetiRenderla(){
  const ul = document.getElementById('sepetListesi');
  ul.innerHTML = '';
  if(satinalmaSepeti.length === 0){ ul.innerHTML = '<li class="empty">Sepet boş</li>'; }
  else{
    satinalmaSepeti.forEach(x=>{
      const urun = ILAC_KATALOG.find(u=>u.ad===x.ad);
      const li = document.createElement('li'); li.className = 'li-row';
      li.innerHTML = `
        <span class="oturum-satiri">${x.ad} × ${x.adet}</span>
        <span>${paraFormat((urun?urun.fiyat:0) * x.adet)}</span>
        <button class="okut-btn" style="background:var(--ios-red);">− Çıkar</button>
      `;
      li.querySelector('button').addEventListener('click', ()=> sepettenCikar(x.ad));
      ul.appendChild(li);
    });
  }
  const toplam = sepetToplamTutar();
  document.getElementById('sepetToplam').textContent = paraFormat(toplam);
  document.getElementById('btnSepetNakit').disabled = satinalmaSepeti.length === 0;
  document.getElementById('btnSepetKart').disabled = satinalmaSepeti.length === 0;
}

function siparisiOlustur(odemeYontemi){
  const kalemler = satinalmaSepeti.map(x=>{
    const urun = ILAC_KATALOG.find(u=>u.ad===x.ad);
    return { ad:x.ad, adet:x.adet, fiyat:urun.fiyat, kategori:urun.kategori };
  });
  const maxGun = Math.max(...kalemler.map(k=> KATEGORI_TESLIM[k.kategori][1]));
  const minGun = Math.max(...kalemler.map(k=> KATEGORI_TESLIM[k.kategori][0]));
  const gun = minGun + Math.floor(Math.random() * (maxGun - minGun + 1));
  const oyunSaati = gun * 24;
  const siparisler = loadSiparisler();
  siparisler.push({
    id: Date.now(),
    kalemler,
    toplam: sepetToplamTutar(),
    tarih: simdi(),
    oyunSaatToplam: oyunSaati,
    teslimTarihi: Date.now() + oyunSaati * OYUN_SAATI_MS,
    durum: 'yolda',
    odemeYontemi
  });
  saveSiparisler(siparisler);
  satinalmaSepeti = [];
  sepetiRenderla();
  katalogKartlariniRenderla();
  siparislerimiRenderla();
  toast(`Sipariş verildi! Tahmini ${gun} gün içinde kargoya teslim edilecek.`, 'success');
}

document.getElementById('btnSepetNakit').addEventListener('click', ()=>{
  if(satinalmaSepeti.length === 0) return;
  const toplam = sepetToplamTutar();
  if(!bankadanOde(toplam)){ toast('Banka bakiyesi yetersiz! Kredi çekmeyi deneyin.', 'error'); return; }
  siparisiOlustur('BANKA');
});

document.getElementById('btnSepetKart').addEventListener('click', ()=>{
  if(satinalmaSepeti.length === 0) return;
  const toplam = sepetToplamTutar();
  if(firebaseHazir && cihazRolu() === 'merkez'){ uzakPosaGonder(toplam, 'satinalma'); return; }
  posBaglam = 'satinalma';
  posToplamTutar = toplam;
  posAc();
});

function siparisleriKontrolEt(){
  const siparisler = loadSiparisler();
  let degisti = false;
  siparisler.forEach(s=>{
    if(s.durum === 'yolda' && Date.now() >= s.teslimTarihi){
      s.durum = 'teslim edildi';
      const stok = loadStok();
      s.kalemler.forEach(k=>{
        if(stok[k.ad]) stok[k.ad].adet += k.adet;
        else stok[k.ad] = { adet: k.adet, fiyat: k.fiyat };
      });
      saveStok(stok);
      degisti = true;
      toast(`📦 Sipariş teslim edildi: ${s.kalemler.map(k=>k.ad).join(', ')}`, 'success');
    }
  });
  if(degisti){ saveSiparisler(siparisler); stokTablosunuRenderla(); muayeneStokSelectDoldur(); katalogKartlariniRenderla(); }
}

function kalanSureYaz(ms){
  if(ms <= 0) return 'Teslim ediliyor…';
  const oyunSaat = Math.ceil(ms / OYUN_SAATI_MS);
  const gun = Math.floor(oyunSaat / 24);
  const saat = oyunSaat % 24;
  if(gun > 0) return `${gun} gün ${saat} sa. kaldı · 1 sa.=10 sn`;
  return `${saat || 1} oyun saati kaldı · 1 sa.=10 sn`;
}

function siparislerimiRenderla(){
  siparisleriKontrolEt();
  const ul = document.getElementById('siparislerimList');
  const siparisler = loadSiparisler().slice().reverse();
  ul.innerHTML = '';
  if(siparisler.length === 0){ ul.innerHTML = '<li class="empty">Henüz sipariş yok</li>'; return; }
  siparisler.forEach(s=>{
    const li = document.createElement('li');
    const durumHtml = s.durum === 'teslim edildi'
      ? '<span class="tag-ok">✔ TESLİM EDİLDİ</span>'
      : `<span class="tag-wait">🚚 ${kalanSureYaz(s.teslimTarihi - Date.now())}</span>`;
    li.innerHTML = `
      <div class="gecmis-baslik" style="cursor:default;">
        <span>${s.tarih} — ${paraFormat(s.toplam)} (${s.odemeYontemi})</span>${durumHtml}
      </div>
      <div style="font-size:12px;color:var(--ios-label-soft);margin-top:4px;">
        ${s.kalemler.map(k=>`${k.ad} ×${k.adet}`).join(', ')}
      </div>
    `;
    ul.appendChild(li);
  });
}

function stokTablosunuRenderla(){
  const stok = loadStok();
  const body = document.getElementById('stokTabloBody');
  body.innerHTML = '';
  const isimler = Object.keys(stok).filter(ad=> stok[ad].adet > 0);
  if(isimler.length === 0){
    body.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--ios-label-soft);">Depoda henüz teslim alınmış ilaç yok</td></tr>';
    return;
  }
  isimler.forEach(ad=>{
    const s = stok[ad];
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${ad}</td>
      <td>${s.adet}</td>
      <td><span class="pill pill-ok">STOKTA</span></td>
    `;
    body.appendChild(tr);
  });
}

/* ===================== ECZANE KASİYER ===================== */
let kasiyerHastaTc = null;
let kasiyerKalemler = []; // {muayeneIndex, ad, fiyat, okutuldu}

document.getElementById('btnKasiyerBul').addEventListener('click', ()=>{
  kasiyerHastaAra(document.getElementById('kasiyerTcSorgu').value.trim());
});

function kasiyerHastaAra(tc){
  const hastalar = loadHastalar();
  const hasta = hastalar[tc];
  if(!hasta){ toast('Bu T.C. ile kayıtlı hasta bulunamadı.', 'error'); return; }
  document.getElementById('kasiyerTcSorgu').value = tc;
  kasiyerHastaTc = tc;
  document.getElementById('kasiyerHastaAd').textContent = hasta.ad;
  document.getElementById('kasiyerHastaTc').textContent = hasta.tc;
  const fotoBox = document.getElementById('kasiyerHastaKart').querySelector('.id-card-photo');
  fotoBox.innerHTML = '<span>FOTO</span>';
  fotoGetir(tc).then(f=>{ if(f) fotoBox.innerHTML=`<img src="${f}">`; });
  kalemleriTopla(hasta);
  bekleyenListesiRenderla();
  fisRenderla();
}

function kalemleriTopla(hasta){
  const stok = loadStok();
  kasiyerKalemler = [];
  (hasta.muayeneler || []).forEach((m, mi)=>{
    if(m.odendiMi) return;
    (m.receteler || []).forEach((ad)=>{
      kasiyerKalemler.push({
        muayeneIndex: mi, ad,
        fiyat: (stok[ad] && stok[ad].fiyat) || 0,
        okutuldu: false
      });
    });
  });
}

function bekleyenListesiRenderla(){
  const ul = document.getElementById('kasiyerBekleyenList');
  ul.innerHTML = '';
  if(kasiyerKalemler.length === 0){ ul.innerHTML = '<li class="empty">Bekleyen ödenmemiş ilaç yok</li>'; return; }
  kasiyerKalemler.forEach((k, idx)=>{
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `
      <span class="oturum-satiri">💊 ${k.ad} — ${paraFormat(k.fiyat)}</span>
      <button class="okut-btn" data-idx="${idx}" ${k.okutuldu?'disabled':''}>${k.okutuldu?'✔ OKUTULDU':'📟 Okut'}</button>
    `;
    ul.appendChild(li);
  });
  ul.querySelectorAll('.okut-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> sahteOkut(parseInt(btn.dataset.idx, 10), btn));
  });
}

function sahteOkut(idx, btnEl){
  if(kasiyerKalemler[idx].okutuldu) return;
  btnEl.disabled = true;
  btnEl.textContent = 'Taranıyor…';
  setTimeout(()=>{
    kasiyerKalemler[idx].okutuldu = true;
    beep();
    toast(`${kasiyerKalemler[idx].ad} okutuldu ✔`, 'success');
    bekleyenListesiRenderla();
    fisRenderla();
  }, 550);
}

function fisRenderla(){
  const fis = document.getElementById('kasiyerFis');
  if(!kasiyerHastaTc || kasiyerKalemler.length === 0){
    fis.innerHTML = '<div class="fis-empty">' + (kasiyerHastaTc ? 'Bu hastanın ödenmemiş ilacı yok.' : 'Henüz bir hasta seçilmedi.') + '</div>';
    document.getElementById('kasiyerToplam').textContent = paraFormat(0);
    document.getElementById('btnNakitOde').disabled = true;
    document.getElementById('btnKartOku').disabled = true;
    return;
  }
  fis.innerHTML = kasiyerKalemler.map(k=>
    `<div class="fis-row ${k.okutuldu?'checked':''}">
      <span>${k.okutuldu?'✔ ':''}${k.ad}</span><span>${paraFormat(k.fiyat)}</span>
    </div>`
  ).join('');
  const toplam = kasiyerKalemler.reduce((s,k)=> s + k.fiyat, 0);
  document.getElementById('kasiyerToplam').textContent = paraFormat(toplam);
  const hepsiOkutuldu = kasiyerKalemler.every(k=>k.okutuldu);
  document.getElementById('btnNakitOde').disabled = !hepsiOkutuldu;
  document.getElementById('btnKartOku').disabled = !hepsiOkutuldu;
}

function odemeyiTamamla(yontem){
  if(!kasiyerHastaTc) return;
  const hastalar = loadHastalar();
  const hasta = hastalar[kasiyerHastaTc];
  const muayeneIndexleri = new Set(kasiyerKalemler.map(k=>k.muayeneIndex));
  muayeneIndexleri.forEach(mi=>{ hasta.muayeneler[mi].odendiMi = true; });
  saveHastalar(hastalar);
  toast(`Ödeme tamamlandı (${yontem}).`, 'success');
  kasiyerKalemler = [];
  bekleyenListesiRenderla();
  fisRenderla();
}

document.getElementById('btnNakitOde').addEventListener('click', ()=>{
  odemeyiTamamla('NAKİT');
  if(navigator.vibrate) navigator.vibrate([15,40,15]);
});

document.getElementById('btnKasiyerYeni').addEventListener('click', ()=>{
  kasiyerHastaTc = null;
  kasiyerKalemler = [];
  document.getElementById('kasiyerTcSorgu').value = '';
  document.getElementById('kasiyerHastaAd').textContent = 'Hasta seçilmedi';
  document.getElementById('kasiyerHastaTc').textContent = '—';
  document.getElementById('kasiyerHastaKart').querySelector('.id-card-photo').innerHTML = '<span>FOTO</span>';
  bekleyenListesiRenderla();
  fisRenderla();
});

/* ===================== MİNİ POS (KART OKUMA) — hem hasta tahsilatı hem eczane tedarik ödemesi için ===================== */
const posModal=document.getElementById('posModal'),posStage=document.getElementById('posStage'),posAmount=document.getElementById('posAmount'),posPinDots=document.getElementById('posPinDots'),posMsg=document.getElementById('posMsg'),posKeypad=document.getElementById('posKeypad'),posReceipt=document.getElementById('posReceipt'),posContactless=document.getElementById('posContactless');
let posPin='',posIslemBitti=false,posPinTimer=null,posOdemeBasarili=false;
let posBaglam = 'kasiyer'; // 'kasiyer' (hasta tahsilatı) | 'satinalma' (eczane tedarik ödemesi)
let posToplamTutar = 0;

function posTimerTemizle(){if(posPinTimer){clearTimeout(posPinTimer);posPinTimer=null}}
function posSes(tip){
  try{const C=window.AudioContext||window.webkitAudioContext; if(!C)return; const c=new C(),g=c.createGain(),o=c.createOscillator();g.connect(c.destination);o.connect(g);let now=c.currentTime;
    if(tip==='print'){[0,1,2,3,4].forEach(i=>{o.frequency.setValueAtTime(480+(i%2)*80,now+i*.055);g.gain.setValueAtTime(.001,now+i*.055);g.gain.exponentialRampToValueAtTime(.09,now+i*.055+.012);g.gain.exponentialRampToValueAtTime(.001,now+i*.055+.045)});o.start(now);o.stop(now+.3)}
    else if(tip==='tear'){o.type='sawtooth';o.frequency.setValueAtTime(1900,now);o.frequency.exponentialRampToValueAtTime(180,now+.28);g.gain.setValueAtTime(.001,now);g.gain.exponentialRampToValueAtTime(.18,now+.015);g.gain.exponentialRampToValueAtTime(.001,now+.3);o.start(now);o.stop(now+.31)}
    else if(tip==='ok'){o.frequency.value=880;g.gain.value=.08;o.start(now);o.stop(now+.12);setTimeout(()=>{try{const c2=new C(),o2=c2.createOscillator(),g2=c2.createGain();o2.frequency.value=1320;g2.gain.value=.06;o2.connect(g2);g2.connect(c2.destination);o2.start();o2.stop(c2.currentTime+.16)}catch(e){}},100)}
    else if(tip==='bekleme'){o.frequency.value=700;g.gain.value=.05;o.start(now);o.stop(now+.08)}
    else {o.frequency.value=220;g.gain.value=.08;o.start(now);o.stop(now+.25)}
  }catch(e){}
}
function posPinEkraninaGec(){if(posIslemBitti)return;posTimerTemizle();posStage.textContent='ŞİFRE GİRİN';posMsg.textContent='5 saniye doldu. Kart şifresini girin.';posContactless.classList.add('hidden');posKeypad.classList.remove('hidden');posKeypad.querySelectorAll('button').forEach(b=>b.disabled=false);posPin='';posPinDotsGuncelle()}

function posFisiHazirla(toplam,yontem){
  let satirlar, baslik;
  if(posBaglam === 'satinalma'){
    baslik = 'TEDARİKÇİ FİŞİ';
    satirlar = satinalmaSepetiSonKalemler.map(k=>`<div class="fis-row"><span>${k.ad} ×${k.adet}</span><span>${paraFormat(k.fiyat*k.adet)}</span></div>`).join('');
  }else{
    baslik = 'ECZANE FİŞİ';
    satirlar = kasiyerKalemler.map(k=>`<div class="fis-row"><span>${k.ad}</span><span>${paraFormat(k.fiyat)}</span></div>`).join('');
  }
  posReceipt.innerHTML=`<div class="pos-paper-title">${baslik}</div><div class="pos-paper-date">${simdi()}</div>${satirlar}<div class="fis-row pos-paper-total"><span>TOPLAM</span><span>${paraFormat(toplam)}</span></div><div class="pos-paper-ok">${yontem==='TEMASSIZ'?'TEMASSIZ KART':'KART'} İLE ÖDENDİ ✔</div><div class="pos-paper-hint">👉 Sağa kaydırıp koparın</div>`;
  posReceipt.classList.remove('hidden');posReceipt.classList.remove('pos-paper-print','pos-paper-tear');
  requestAnimationFrame(()=>posReceipt.classList.add('pos-paper-print'));posSes('print');
}
let satinalmaSepetiSonKalemler = [];
function posFisiKopar(){
  if(!posOdemeBasarili)return; posReceipt.classList.add('pos-paper-tear'); posSes('tear');
  if(navigator.vibrate)navigator.vibrate([25,20,45]);
  setTimeout(()=>{
    posReceipt.classList.add('hidden');posReceipt.classList.remove('pos-paper-tear');posTimerTemizle();posModal.classList.add('hidden');
    if(posBaglam === 'satinalma') siparisiOlustur('KART');
    else odemeyiTamamla('KART');
  },420);
}
function posSonucGoster(basarili,toplam,yontem){
  posIslemBitti=true;posOdemeBasarili=basarili;posTimerTemizle();posKeypad.querySelectorAll('button').forEach(b=>b.disabled=true);posContactless.classList.add('hidden');
  if(!basarili){posStage.textContent='❌ YETERSİZ BAKİYE';posMsg.textContent='Kartta yeterli bakiye bulunamadı.';posSes('fail');posReceipt.classList.add('hidden');posReceipt.innerHTML='';return}
  posStage.textContent='✅ ONAYLANDI';posMsg.textContent='Fiş hazırlanıyor…';posSes('ok');posFisiHazirla(toplam,yontem);
}
function posOdemeBaslat(yontem){
  if(posIslemBitti||posToplamTutar<=0)return;
  const toplam = posToplamTutar;
  posIslemBitti=true;posStage.textContent='İŞLEM YAPILIYOR…';posMsg.textContent=yontem==='TEMASSIZ'?'Temassız ödeme işleniyor…':'Lütfen bekleyin';
  posKeypad.querySelectorAll('button').forEach(b=>b.disabled=true);
  setTimeout(()=>{const yetersizBakiye=Math.random()<.10;posIslemBitti=false;posSonucGoster(!yetersizBakiye,toplam,yontem)},900);
}

function posAc(){
  if(posBaglam === 'satinalma'){ satinalmaSepetiSonKalemler = satinalmaSepeti.map(x=>({...x, fiyat:(ILAC_KATALOG.find(u=>u.ad===x.ad)||{}).fiyat||0})); }
  posTimerTemizle();posPin='';posIslemBitti=false;posOdemeBasarili=false;
  posStage.textContent='KARTI YAKLAŞTIRIN';posMsg.textContent='POS ekranının üstüne dokunun: TEMASSIZ';
  posAmount.textContent=paraFormat(posToplamTutar);posPinDotsGuncelle();
  posReceipt.classList.add('hidden');posReceipt.innerHTML='';
  posKeypad.classList.add('hidden');posContactless.classList.remove('hidden');
  posModal.classList.remove('hidden');posPinTimer=setTimeout(posPinEkraninaGec,5000);
}

document.getElementById('btnKartOku').addEventListener('click',()=>{
  if(kasiyerKalemler.length===0)return;
  const toplam = kasiyerKalemler.reduce((s,k)=>s+k.fiyat,0);
  if(firebaseHazir && cihazRolu() === 'merkez'){ uzakPosaGonder(toplam, 'kasiyer'); return; }
  posBaglam = 'kasiyer';
  posToplamTutar = toplam;
  posAc();
});
document.getElementById('btnPosClose').addEventListener('click',()=>{posTimerTemizle();posModal.classList.add('hidden')});
function posPinDotsGuncelle(){posPinDots.querySelectorAll('span').forEach((x,i)=>x.classList.toggle('filled',i<posPin.length))}
posContactless.addEventListener('click',()=>{posTimerTemizle();posOdemeBaslat('TEMASSIZ')});
posKeypad.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||posIslemBitti)return;const k=b.dataset.k;if(k==='C'){posPin=posPin.slice(0,-1);posPinDotsGuncelle();return}if(k==='OK'){if(posPin.length<4){posMsg.textContent='En az 4 haneli şifre girin.';return}posOdemeBaslat('ŞİFRE');return}if(/^\d$/.test(k)&&posPin.length<4){posPin+=k;posPinDotsGuncelle()}});
/* Fişi parmağınla sağa sürükleyip koparma */
let fisDrag=false,fisStartX=0,fisX=0;
posReceipt.addEventListener('pointerdown',e=>{if(!posOdemeBasarili)return;fisDrag=true;fisStartX=e.clientX;fisX=0;posReceipt.setPointerCapture?.(e.pointerId);posReceipt.classList.add('pos-paper-drag')});
posReceipt.addEventListener('pointermove',e=>{if(!fisDrag)return;fisX=Math.max(0,e.clientX-fisStartX);posReceipt.style.transform=`translate(${fisX}px, -50%) rotate(${Math.min(8,fisX/28)}deg)`});
posReceipt.addEventListener('pointerup',()=>{if(!fisDrag)return;fisDrag=false;posReceipt.classList.remove('pos-paper-drag');if(fisX>posReceipt.offsetWidth*.32){posReceipt.style.transform='translate(125vw,-50%) rotate(14deg)';posFisiKopar()}else{posReceipt.style.transform='translate(0,-50%) rotate(0)';}});
posReceipt.addEventListener('pointercancel',()=>{fisDrag=false;posReceipt.style.transform='translate(0,-50%) rotate(0)'});

/* ===================== CİHAZ ROLÜ (Ana Merkez / POS) VE UZAK EŞLEŞTİRME ===================== */
function cihazRolu(){ return localStorage.getItem('hastane_cihaz_rolu') || null; }

function rolSecimEkraniniGoster(){
  document.getElementById('rolSecimEkrani').classList.remove('hidden');
}
document.querySelectorAll('.rol-sec-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    localStorage.setItem('hastane_cihaz_rolu', btn.dataset.rol);
    document.getElementById('rolSecimEkrani').classList.add('hidden');
    cihazRoluneGoreBaslat();
  });
});

function cihazRoluneGoreBaslat(){
  const rol = cihazRolu();
  document.body.classList.remove('rol-pos','rol-merkez');
  if(rol === 'pos'){
    document.body.classList.add('rol-pos');
    try{ if(screen.orientation && screen.orientation.lock) screen.orientation.lock('portrait').catch(()=>{}); }catch(e){}
    posBekleModuBaslat();
    // POS tarafında da eşleştirme ekranına erişim her zaman açık olsun.
    document.getElementById('btnPosEslesme')?.classList.remove('hidden');
  }else if(rol === 'merkez'){
    document.body.classList.add('rol-merkez');
    try{ if(screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(()=>{}); }catch(e){}
    firebaseBaslat();
  }else{
    rolSecimEkraniniGoster();
  }
}

/* --- Firebase ile gerçek zamanlı eşleştirme (koda gömülü — ekstra kurulum gerekmez) --- */
const HASTANE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBbGR4xRho-jXPZeNdPINO31h_gLc9epBU",
  authDomain: "hastane-oyunu.firebaseapp.com",
  databaseURL: "https://hastane-oyunu-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "hastane-oyunu",
  storageBucket: "hastane-oyunu.firebasestorage.app",
  messagingSenderId: "1079050009396",
  appId: "1:1079050009396:web:e4f4c0069dab54824b4361"
};
const HASTANE_OTURUM_KODU = "kardesler1";

let firebaseHazir = false, firebaseDB = null;
function firebaseAyarlariniYukle(){
  // Kullanıcı eşleştirme ekranından özel bir ayar girdiyse onu kullan, yoksa koda gömülü varsayılanı kullan.
  try{
    const ozel = JSON.parse(localStorage.getItem('hastane_firebase_ayar') || 'null');
    if(ozel && ozel.config && ozel.oturumKodu) return ozel;
  }catch(e){ /* yoksay */ }
  return { config: HASTANE_FIREBASE_CONFIG, oturumKodu: HASTANE_OTURUM_KODU };
}
function firebaseBaslat(){
  const ayar = firebaseAyarlariniYukle();
  if(!ayar || !ayar.config || !ayar.oturumKodu) return false;
  if(typeof firebase === 'undefined') return false;
  try{
    if(!firebase.apps || firebase.apps.length === 0) firebase.initializeApp(ayar.config);
    firebaseDB = firebase.database();
    firebaseHazir = true;
    document.getElementById('eslesmeDurumu').textContent = '🟢 Eşleşme aktif: ' + ayar.oturumKodu;
    return true;
  }catch(e){
    document.getElementById('eslesmeDurumu').textContent = '🔴 Eşleşme hatası: ' + e.message;
    return false;
  }
}
function firebaseYolu(alt){
  const ayar = firebaseAyarlariniYukle();
  return `sync/${ayar.oturumKodu}/${alt}`;
}

document.getElementById('btnEslesmeKaydet').addEventListener('click', ()=>{
  const kodu = document.getElementById('eslesmeOturumKodu').value.trim();
  const configRaw = document.getElementById('eslesmeConfig').value.trim();
  if(!kodu || !configRaw){ toast('Oturum kodu ve Firebase yapılandırmasını girin.', 'error'); return; }
  try{
    const config = JSON.parse(configRaw);
    localStorage.setItem('hastane_firebase_ayar', JSON.stringify({ oturumKodu: kodu, config }));
    toast('Eşleştirme ayarları kaydedildi.', 'success');
    document.getElementById('eslesmeModal').classList.add('hidden');
    firebaseBaslat();
    if(cihazRolu() === 'pos') posDinlemeyiBaslat();
  }catch(e){
    toast('Firebase yapılandırması geçersiz JSON.', 'error');
  }
});
document.getElementById('btnPosEslesme')?.addEventListener('click', ()=> document.getElementById('btnEslesmeAc').click());
document.getElementById('btnEslesmeAc').addEventListener('click', ()=>{
  const ayar = firebaseAyarlariniYukle();
  if(ayar){
    document.getElementById('eslesmeOturumKodu').value = ayar.oturumKodu;
    document.getElementById('eslesmeConfig').value = JSON.stringify(ayar.config, null, 2);
  }
  document.getElementById('eslesmeModal').classList.remove('hidden');
});
document.getElementById('btnEslesmeKapat').addEventListener('click', ()=>{
  document.getElementById('eslesmeModal').classList.add('hidden');
});

/* Ana Merkez: kartla öde -> uzak POS'a istek gönder */
function uzakPosaGonder(tutar, baglam){
  if(!firebaseHazir){ posBaglam = baglam; posToplamTutar = tutar; posAc(); return; } // yapılandırma yoksa yerel modal ile devam
  const istekId = Date.now();
  document.getElementById('merkezPosDurumModal').classList.remove('hidden');
  document.getElementById('merkezPosDurumMetni').textContent = 'POS cihazına veri gönderiliyor…';
  const bekleSesi = setInterval(()=> posSes('bekleme'), 500);
  firebaseDB.ref(firebaseYolu('istek')).set({ id: istekId, tutar, baglam, zaman: Date.now() });
  setTimeout(()=>{
    clearInterval(bekleSesi);
    posSes('ok');
    document.getElementById('merkezPosDurumMetni').textContent = 'Gönderildi ✔ POS cihazında ödeme bekleniyor…';
    const ref = firebaseDB.ref(firebaseYolu('sonuc'));
    const dinleyici = ref.on('value', snap=>{
      const veri = snap.val();
      if(veri && veri.id === istekId){
        ref.off('value', dinleyici);
        document.getElementById('merkezPosDurumModal').classList.add('hidden');
        if(veri.basarili){
          if(baglam === 'satinalma') siparisiOlustur(veri.yontem === 'TEMASSIZ' ? 'TEMASSIZ KART' : 'KART');
          else odemeyiTamamla(veri.yontem === 'TEMASSIZ' ? 'TEMASSIZ KART' : 'KART');
        }else{
          toast('POS cihazında ödeme reddedildi (yetersiz bakiye).', 'error');
        }
      }
    });
  }, 2000);
}
document.getElementById('btnMerkezPosIptal').addEventListener('click', ()=>{
  document.getElementById('merkezPosDurumModal').classList.add('hidden');
});

/* POS cihazı: bekleme ekranı + gelen istekleri dinleme */
let posSonIslenenId = null;
function posBekleModuBaslat(){
  document.getElementById('posBekleEkrani').classList.remove('hidden');
  document.getElementById('posBekleMetni').textContent = firebaseHazir ? 'POS HAZIR' : 'BAĞLANTI BEKLENİYOR';
  if(firebaseBaslat()) posDinlemeyiBaslat();
}
function posDinlemeyiBaslat(){
  if(!firebaseHazir) return;
  firebaseDB.ref(firebaseYolu('istek')).on('value', snap=>{
    const istek = snap.val();
    if(!istek || istek.id === posSonIslenenId) return;
    posSonIslenenId = istek.id;
    posUzakIslemBaslat(istek);
  });
}
function posUzakIslemBaslat(istek){
  document.getElementById('posBekleEkrani').classList.add('hidden');
  posBaglam = istek.baglam;
  posToplamTutar = istek.tutar;
  posStage.textContent = 'VERİ OKUNUYOR…';
  posMsg.textContent = '';
  posAmount.textContent = '';
  posSes('bekleme');
  posModal.classList.remove('hidden');
  posContactless.classList.remove('hidden');
  posKeypad.classList.add('hidden');
  posPin=''; posIslemBitti=false; posOdemeBasarili=false; posPinDotsGuncelle();
  setTimeout(()=>{
    posStage.textContent = 'TUTAR';
    posAmount.textContent = paraFormat(posToplamTutar);
    posMsg.textContent = 'Yukarıya dokunun (temassız) veya kart şifresi girin';
    posPinTimer = setTimeout(posPinEkraninaGec, 5000);
  }, 1200);
}
/* POS'ta işlem sonuçlandığında uzak Ana Merkez'e bildir */
const _eskiPosSonucGoster = posSonucGoster;
posSonucGoster = function(basarili, toplam, yontem){
  _eskiPosSonucGoster(basarili, toplam, yontem);
  if(firebaseHazir && cihazRolu() === 'pos'){
    firebaseDB.ref(firebaseYolu('sonuc')).set({ id: posSonIslenenId, basarili, yontem, zaman: Date.now() });
  }
};
const _eskiPosFisiKopar = posFisiKopar;
posFisiKopar = function(){
  if(cihazRolu() === 'pos'){
    if(!posOdemeBasarili) return;
    posReceipt.classList.add('pos-paper-tear'); posSes('tear');
    if(navigator.vibrate) navigator.vibrate([25,20,45]);
    setTimeout(()=>{
      posReceipt.classList.add('hidden');posReceipt.classList.remove('pos-paper-tear');posTimerTemizle();
      posModal.classList.add('hidden');
      document.getElementById('posBekleEkrani').classList.remove('hidden');
      document.getElementById('posBekleMetni').textContent = firebaseHazir ? 'POS HAZIR' : 'BAĞLANTI BEKLENİYOR';
    }, 420);
  }else{
    _eskiPosFisiKopar();
  }
};

/* ===================== BORÇLAR ===================== */
function tumBorclariHesapla(){
  const hastalar = loadHastalar();
  const stok = loadStok();
  const sonuc = [];
  Object.values(hastalar).forEach(hasta=>{
    let tutar = 0;
    (hasta.muayeneler || []).forEach(m=>{
      if(m.odendiMi) return;
      (m.receteler || []).forEach(ad=>{ tutar += (stok[ad] && stok[ad].fiyat) || 0; });
    });
    if(tutar > 0) sonuc.push({ tc: hasta.tc, ad: hasta.ad, tutar });
  });
  return sonuc;
}

function genelBorcToplami(){
  return tumBorclariHesapla().reduce((s,x)=> s + x.tutar, 0);
}

function borclarSekmesiniRenderla(){
  const borclar = tumBorclariHesapla();
  document.getElementById('borcGenelToplam').textContent = paraFormat(genelBorcToplami());
  const ul = document.getElementById('borclarList');
  ul.innerHTML = '';
  if(borclar.length === 0){ ul.innerHTML = '<li class="empty">Borcu olan hasta yok 🎉</li>'; return; }
  borclar.forEach(b=>{
    const li = document.createElement('li'); li.className = 'li-row';
    li.innerHTML = `
      <span>👤 ${b.ad} <span style="color:var(--text-soft);font-size:11px;">(${b.tc})</span></span>
      <span class="borc-tutar">${paraFormat(b.tutar)}</span>
      <button class="okut-btn" style="background:var(--teal-700);">Öde</button>
    `;
    li.querySelector('.okut-btn').addEventListener('click', ()=>{
      sekmeyeGec('kasiyer');
      kasiyerHastaAra(b.tc);
    });
    ul.appendChild(li);
  });
}

/* ===================== BORÇ HATIRLATMA (her 5 dakikada bir) ===================== */
if('Notification' in window && Notification.permission === 'default'){
  try{ Notification.requestPermission(); }catch(e){ /* yoksay */ }
}

function borcHatirlatmasiniKontrolEt(){
  const toplam = genelBorcToplami();
  if(toplam <= 0) return;
  const mesaj = `Toplam ${paraFormat(toplam)} tahsil edilmemiş borç var.`;
  if('Notification' in window && Notification.permission === 'granted'){
    try{
      new Notification('🧾 Borç Hatırlatma', { body: mesaj, icon: 'icon-192.png' });
      return;
    }catch(e){ /* toast'a düş */ }
  }
  toast(mesaj, 'error');
}
setInterval(borcHatirlatmasiniKontrolEt, 5 * 60 * 1000);

/* ===================== BAŞLANGIÇ STOĞU (ilk açılışta birkaç ilaç hazır bulunsun) ===================== */
function baslangicStokunuHazirla(){
  if(localStorage.getItem('hastane_baslangic_stok_verildi')) return;
  const stok = loadStok();
  const hediye = { 'Parol': 8, 'Aspirin': 6, 'Öksürük Şurubu': 5, 'Burun Damlası': 4, 'Serum İğnesi': 5 };
  Object.keys(hediye).forEach(ad=>{
    const urun = ILAC_KATALOG.find(u=>u.ad===ad);
    if(stok[ad]) stok[ad].adet += hediye[ad];
    else stok[ad] = { adet: hediye[ad], fiyat: urun ? urun.fiyat : 0 };
  });
  saveStok(stok);
  localStorage.setItem('hastane_baslangic_stok_verildi', '1');
}

/* ===================== BAŞLANGIÇ ===================== */
baslangicStokunuHazirla();
hastalariFotolariOptimizeEt();
stokTablosunuRenderla();
muayeneStokSelectDoldur();
receteListesiRenderla();
bekleyenListesiRenderla();
fisRenderla();
kayitliHastalariRenderla();
hastaSecimListesiniDoldur();
idKartOnizlemeGuncelle();
setInterval(siparislerimiRenderla, 60 * 1000);
